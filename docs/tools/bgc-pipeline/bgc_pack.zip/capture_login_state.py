from playwright.sync_api import sync_playwright

BASE_URL = "https://rahaustinwest.clearcareonline.com/"

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    context = browser.new_context(viewport={"width": 1400, "height": 900})
    page = context.new_page()
    page.goto(BASE_URL)

    print("➡️  Login manually. Once you log in, please return to this console.")
    input("✅ Press ENTER to save the log in state...")

    context.storage_state(path="login_state.json")
    print("💾 Saved: login_state.json")
    context.close()
    browser.close()
