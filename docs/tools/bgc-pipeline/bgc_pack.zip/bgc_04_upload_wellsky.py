"""
BGC WellSky Upload Script — Right at Home Austin West
======================================================
Script 4 de 4: Upload masivo de PDFs a WellSky

Qué hace:
  1. Lee la estructura de carpetas en C:\BGC\FECHA\
  2. Para cada CG busca su perfil en WellSky por nombre
  3. Sube los 6 PDFs (CBC, EMR, NAR, TXOIG, USOIG, TXDPS) a la sección Files
  4. Genera log de resultados

Prerequisitos:
  - Haber corrido bgc_03_auditoria.py y verificado resultados
  - Tener login_state.json en C:\BGC\ (correr capture_login_state.py si no existe)
  - pip install playwright pandas
  - playwright install chromium

Uso:
  python bgc_04_upload_wellsky.py

  Para un solo CG:
  python bgc_04_upload_wellsky.py --cg ADAMS_DOMINIC

Autor: Angel Pabuence — Right at Home Austin West
"""

import os
import re
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace") if hasattr(sys.stdout, "reconfigure") else None
import time
import argparse
from datetime import date
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# ─────────────────────────────────────────────────────────────
#  CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────


def _get_onedrive_root():
    """Detecta la ruta correcta de OneDrive según el usuario del PC."""
    import getpass
    user     = getpass.getuser().lower()
    onedrive = f"C:\\Users\\{getpass.getuser()}\\OneDrive - Right At Home"
    RUTAS = {
        "a.pabuence": os.path.join(onedrive, "BGC_Anual"),
        "angel":      os.path.join(onedrive, "BGC_Anual"),
        "danny":      os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual"),
        "d.tobon":    os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual"),
    }
    if user in RUTAS:
        return RUTAS[user]
    shared = os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual")
    own    = os.path.join(onedrive, "BGC_Anual")
    if os.path.exists(shared): return shared
    if os.path.exists(own):    return own
    return own

BGC_ROOT         = _get_onedrive_root()
FECHA            = date.today().strftime("%Y%m%d")  # cambiar si es necesario: "20260615"
LOGIN_STATE      = os.path.join(BGC_ROOT, "login_state.json")
WELLSKY_URL      = "https://rahaustinwest.clearcareonline.com/"
PLATAFORMAS      = ["CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS"]
HEADLESS         = False   # True para correr sin ventana visible
PAUSA_ENTRE_CG   = 1.5    # segundos entre caregivers

# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────

def log(msg, tipo="INFO"):
    simbolo = {"INFO": "->", "OK": "OK", "ERROR": "ERR", "WARN": "(!)"}.get(tipo, "->")
    print(f"  {simbolo} {msg}")

def nombre_desde_carpeta(carpeta):
    """Convierte ADAMS_DOMINIC en 'Dominic Adams' para búsqueda en WellSky."""
    partes = carpeta.split("_", 1)
    if len(partes) == 2:
        apellido = partes[0].title()
        nombre   = partes[1].replace("_", " ").title()
        return f"{nombre} {apellido}"
    return carpeta.replace("_", " ").title()

def obtener_pdfs(ruta_cg):
    """Retorna dict {plataforma: ruta_pdf} para una carpeta de CG."""
    pdfs = {}
    try:
        for archivo in os.listdir(ruta_cg):
            if archivo.endswith(".pdf"):
                for plat in PLATAFORMAS:
                    if f"_AnnualBGC_{plat}" in archivo:
                        pdfs[plat] = os.path.join(ruta_cg, archivo)
    except Exception as e:
        log(f"Error leyendo carpeta: {e}", "ERROR")
    return pdfs

# ─────────────────────────────────────────────────────────────
#  NAVEGACIÓN WELLSKY
# ─────────────────────────────────────────────────────────────

def buscar_caregiver(page, nombre_busqueda):
    """
    Busca un CG en WellSky usando el buscador.
    Retorna True si navegó al perfil, False si no lo encontró.
    """
    try:
        # Click en el ícono de búsqueda de personas
        page.click("a.butPpl", timeout=8000)
        page.wait_for_selector("#profile_search", timeout=8000)

        # Limpiar y llenar campo de búsqueda
        page.fill("#profile_search", "")
        page.type("#profile_search", nombre_busqueda, delay=80)

        # Esperar que aparezca el autocomplete
        page.wait_for_selector(".ui-autocomplete a.item", timeout=8000)
        page.wait_for_timeout(500)  # pequeña pausa para que cargue completo

        # Click en el primer resultado
        resultados = page.query_selector_all(".ui-autocomplete a.item")
        if not resultados:
            return False

        resultados[0].click()
        page.wait_for_load_state("networkidle")
        return True

    except PWTimeout:
        return False
    except Exception as e:
        log(f"Error en búsqueda: {e}", "ERROR")
        return False

def obtener_edit_profile_id(page):
    """Extrae el edit_profile_id del perfil actual."""
    try:
        link = page.query_selector('a.edit-profile[href*="/profile/edit/"][role="caregiver"]')
        if not link:
            # Fallback: buscar cualquier link de edit-profile
            link = page.query_selector('a.edit-profile[href*="/profile/edit/"]')
        if not link:
            return None
        href = link.get_attribute("href")
        match = re.search(r'/profile/edit/(\d+)/', href)
        if match:
            return match.group(1)
        return None
    except Exception as e:
        log(f"Error obteniendo edit_profile_id: {e}", "ERROR")
        return None

def subir_pdf(page, edit_profile_id, pdf_path, nombre_archivo):
    """
    Sube un PDF a WellSky usando la API de upload.
    POST a /profile/upload-file/{edit_profile_id}/
    """
    try:
        upload_url = f"{WELLSKY_URL.rstrip('/')}/profile/upload-file/{edit_profile_id}/"
        current_url = page.url

        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()

        response = page.request.post(
            upload_url,
            multipart={
                "userfile": {
                    "name":     nombre_archivo,
                    "mimeType": "application/pdf",
                    "buffer":   pdf_bytes,
                }
            },
            headers={
                "origin":  WELLSKY_URL.rstrip("/"),
                "referer": current_url,
            }
        )

        if response.status in [200, 201, 302]:
            return True
        else:
            log(f"Upload falló con status {response.status}", "ERROR")
            return False

    except Exception as e:
        log(f"Error subiendo {nombre_archivo}: {e}", "ERROR")
        return False

# ─────────────────────────────────────────────────────────────
#  PROCESAR UN CG
# ─────────────────────────────────────────────────────────────

def procesar_cg(page, carpeta, ruta_cg):
    """
    Procesa un CG completo: busca en WellSky y sube todos sus PDFs.
    Retorna (subidos, fallidos, no_encontrado)
    """
    nombre_busqueda = nombre_desde_carpeta(carpeta)
    pdfs = obtener_pdfs(ruta_cg)

    if not pdfs:
        log(f"Sin PDFs en carpeta — saltando", "WARN")
        return 0, 0, True

    log(f"Buscando: {nombre_busqueda}")

    # Buscar CG en WellSky
    encontrado = buscar_caregiver(page, nombre_busqueda)
    if not encontrado:
        log(f"No encontrado en WellSky: {nombre_busqueda}", "ERROR")
        return 0, len(pdfs), True

    # Obtener edit_profile_id
    edit_id = obtener_edit_profile_id(page)
    if not edit_id:
        log(f"No se pudo obtener edit_profile_id para {nombre_busqueda}", "ERROR")
        return 0, len(pdfs), False

    log(f"Perfil encontrado (ID: {edit_id})")

    # Subir cada PDF
    subidos, fallidos = 0, 0
    for plat, pdf_path in pdfs.items():
        nombre_archivo = os.path.basename(pdf_path)
        ok = subir_pdf(page, edit_id, pdf_path, nombre_archivo)
        if ok:
            log(f"  ✓ {nombre_archivo}", "OK")
            subidos += 1
        else:
            log(f"  ✗ {nombre_archivo}", "ERROR")
            fallidos += 1
        time.sleep(0.3)

    return subidos, fallidos, False

# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="BGC WellSky Upload")
    parser.add_argument("--cg", default=None,
                        help='Subir solo un CG, ej: ADAMS_DOMINIC')
    args = parser.parse_args()

    print(f"\n{'='*65}")
    print(f"  BGC Upload WellSky — Right at Home Austin West")
    print(f"  Fecha: {FECHA}")
    print(f"{'='*65}\n")

    # Verificar login_state
    if not os.path.exists(LOGIN_STATE):
        print(f"  ERROR: No se encontró {LOGIN_STATE}")
        print(f"  Corre capture_login_state.py primero.")
        return

    # Obtener carpetas
    carpeta_fecha = os.path.join(BGC_ROOT, FECHA)
    if not os.path.exists(carpeta_fecha):
        print(f"  ERROR: No existe {carpeta_fecha}")
        return

    carpetas = sorted([
        d for d in os.listdir(carpeta_fecha)
        if os.path.isdir(os.path.join(carpeta_fecha, d))
    ])

    # Filtrar si se especificó un CG
    if args.cg:
        carpetas = [c for c in carpetas if c.upper() == args.cg.upper()]
        if not carpetas:
            print(f"  ERROR: No se encontró la carpeta {args.cg}")
            return

    print(f"[1/2] {len(carpetas)} CGs a procesar en {carpeta_fecha}")

    # Resultados
    total_subidos     = 0
    total_fallidos    = 0
    cgs_ok            = []
    cgs_fallidos      = []
    cgs_no_encontrado = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        context = browser.new_context(storage_state=LOGIN_STATE)
        page    = context.new_page()

        print(f"\n[2/2] Iniciando upload...\n")

        # Ir a WellSky primero para verificar sesión
        page.goto(WELLSKY_URL, wait_until="networkidle")
        if "login" in page.url.lower():
            print("  ERROR: Sesión expirada. Corre capture_login_state.py de nuevo.")
            browser.close()
            return

        log("Sesión WellSky activa", "OK")

        for i, carpeta in enumerate(carpetas, 1):
            ruta_cg = os.path.join(carpeta_fecha, carpeta)
            print(f"\n  [{i}/{len(carpetas)}] {carpeta}")

            subidos, fallidos, no_encontrado = procesar_cg(page, carpeta, ruta_cg)

            total_subidos  += subidos
            total_fallidos += fallidos

            if no_encontrado:
                cgs_no_encontrado.append(carpeta)
            elif fallidos > 0:
                cgs_fallidos.append(carpeta)
            else:
                cgs_ok.append(carpeta)

            time.sleep(PAUSA_ENTRE_CG)

        browser.close()

    # Resumen final
    print(f"\n{'='*65}")
    print(f"  Upload completo.")
    print(f"  → PDFs subidos:        {total_subidos}")
    print(f"  → PDFs fallidos:       {total_fallidos}")
    print(f"  → CGs completados:     {len(cgs_ok)}")
    print(f"  → CGs con errores:     {len(cgs_fallidos)}")
    print(f"  → CGs no encontrados:  {len(cgs_no_encontrado)}")

    if cgs_fallidos:
        print(f"\n  Con errores:")
        for c in cgs_fallidos: print(f"    - {c}")

    if cgs_no_encontrado:
        print(f"\n  No encontrados en WellSky:")
        for c in cgs_no_encontrado: print(f"    - {c}")

    print(f"{'='*65}\n")

if __name__ == "__main__":
    main()
