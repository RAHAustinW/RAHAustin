"""
BGC Audit Script — Right at Home Austin West
=============================================
Script 3 de 4: Auditoría de Background Checks

Qué hace:
  1. Lee la estructura de carpetas en C:\BGC\FECHA\
  2. Para cada CG encuentra sus 6 PDFs
  3. Lee el texto de cada PDF y aplica lógica de detección
  4. Genera Excel de auditoría con:
       - Una fila por CG
       - Columna por plataforma: CLEAR / HIT / FALTA
       - Resumen de novedades
       - Hoja de HITs para revisión del equipo

Lógica de detección:
  EMR   → HIT si Misconduct Date/Type/Registry tienen datos
  NAR   → HIT si columna Unemployable tiene valor 'Yes'
  TXOIG → HIT si NO contiene 'No search result(s) found.'
  USOIG → HIT si NO contiene frases de no resultado
  CBC   → HIT si contiene 'ARREST SUMMARY' con datos reales
  TXDPS → HIT si contiene eventos en EVENT HISTORY

Uso:
  python bgc_03_auditoria.py

Requisitos:
  pip install pdfplumber pandas openpyxl

Autor: Angel Pabuence — Right at Home Austin West
"""

import os
import re
from datetime import date
import pandas as pd
import pdfplumber
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
import openpyxl

# ─────────────────────────────────────────────────────────────
#  CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────


def _get_onedrive_root():
    """Detecta la ruta correcta de OneDrive según el usuario del PC."""
    import getpass
    user     = getpass.getuser().lower()
    onedrive = f"C:\\Users\\{getpass.getuser()}\\OneDrive - Right At Home"
    RUTAS = {
        "a.pabuence": os.path.join(onedrive, "BGC_Anual"),
        "angel":      os.path.join(onedrive, "BGC_Anual"),
        "danny":      os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual"),
        "d.tobon":    os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual"),
    }
    if user in RUTAS:
        return RUTAS[user]
    shared = os.path.join(onedrive, "Angel Pabuence\'s files - BGC_Anual")
    own    = os.path.join(onedrive, "BGC_Anual")
    if os.path.exists(shared): return shared
    if os.path.exists(own):    return own
    return own

BGC_ROOT    = _get_onedrive_root()
FECHA       = "20260702"
PLATAFORMAS = ["CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS"]

# ─────────────────────────────────────────────────────────────
#  COLORES
# ─────────────────────────────────────────────────────────────

C_CLEAR  = "E2EFDA"
C_HIT    = "FCE4D6"
C_FALTA  = "FFF2CC"
C_HEADER = "1F4E79"
C_HIT_B  = "FF0000"

def fill(h):  return PatternFill("solid", fgColor=h)
def bw():     return Font(bold=True, color="FFFFFF")
def border():
    s = Side(style="thin", color="BFBFBF")
    return Border(left=s, right=s, top=s, bottom=s)

# ─────────────────────────────────────────────────────────────
#  LEER PDF
# ─────────────────────────────────────────────────────────────

def leer_pdf(ruta_pdf):
    try:
        with pdfplumber.open(ruta_pdf) as pdf:
            texto = ""
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    texto += t + "\n"
        return texto
    except Exception as e:
        return f"ERROR: {e}"

# ─────────────────────────────────────────────────────────────
#  LÓGICA DE DETECCIÓN POR PLATAFORMA
# ─────────────────────────────────────────────────────────────

def detectar_emr(texto):
    """
    EMR — HIT si hay datos en Misconduct Date/Type/Registry.
    La fila del CG tiene solo nombre y apellido si es CLEAR.
    Si hay fecha de misconduct (MM/DD/YYYY) fuera del header, es HIT.
    """
    if texto.startswith("ERROR"): return "ERROR"
    lineas = texto.split("\n")
    for linea in lineas:
        if "Misconduct Date" in linea or "Employee First Name" in linea:
            continue
        if "Report Generated" in linea:
            continue
        if re.search(r'\d{1,2}/\d{1,2}/\d{4}', linea):
            return "HIT"
    return "CLEAR"

def detectar_nar(texto):
    """
    NAR — HIT si columna Unemployable tiene valor 'Yes'.
    """
    if texto.startswith("ERROR"): return "ERROR"
    lineas = texto.split("\n")
    for linea in lineas:
        if re.search(r'\bYes\b', linea):
            return "HIT"
    return "CLEAR"

def detectar_txoig(texto):
    """
    TXOIG — CLEAR si contiene 'No search result(s) found.'
    HIT si no lo contiene.
    NOTA: Edge guarda TXOIG como PDF imagen — texto no legible.
    Si el texto está vacío se marca CLEAR* para revisión visual.
    """
    if texto.startswith("ERROR"): return "ERROR"
    if not texto or len(texto.strip()) < 20:
        return "CLEAR*"
    if "No search result(s) found." in texto:
        return "CLEAR"
    return "HIT"

def detectar_usoig(texto):
    """
    USOIG — CLEAR si contiene frases de no resultado.
    Maneja variaciones del texto de la página.
    """
    if texto.startswith("ERROR"): return "ERROR"
    frases_clear = [
        "No search results found.",
        "No Results were found for",
        "No Records Found",
    ]
    texto_lower = texto.lower()
    for frase in frases_clear:
        if frase.lower() in texto_lower:
            return "CLEAR"
    return "HIT"

def detectar_cbc(texto):
    """
    CBC — El flujo PAD guarda el Detailed Record cuando hay match.
    HIT si contiene 'ARREST SUMMARY' con fechas de arresto reales.
    CLEAR si contiene 'No search results found.' (página sin resultado).
    """
    if texto.startswith("ERROR"): return "ERROR"
    # Página de no resultado
    if "No search results found." in texto:
        return "CLEAR"
    # Detailed Record con arrestos
    if "ARREST SUMMARY" in texto:
        # Verificar que hay fechas reales de arresto
        if re.search(r'\d{1,2}/\d{1,2}/\d{4}', texto):
            return "HIT"
    # Preview page guardada (antes de Display Detailed Record)
    if "SID:" in texto and "Search Criteria" in texto:
        if "ARREST SUMMARY" in texto:
            return "HIT"
    return "CLEAR"

def detectar_txdps(texto):
    """
    TXDPS — CLEAR si no hay eventos en EVENT HISTORY.
    HIT si hay convictions o eventos.
    """
    if texto.startswith("ERROR"): return "ERROR"
    if "INELIGIBLE" in texto:
        return "HIT"
    if "THE RECORD CONTAINS NO HISTORY OF EVENTS" in texto:
        return "CLEAR"
    # Si hay eventos numerados (EVENT 1, EVENT 2, etc.)
    if re.search(r'EVENT\s+\d+', texto):
        return "HIT"
    # Si hay CONVICTION en el historial
    if "CONVICTION" in texto and "EVENT HISTORY" in texto:
        return "HIT"
    return "CLEAR"

DETECTORES = {
    "CBC":   detectar_cbc,
    "EMR":   detectar_emr,
    "NAR":   detectar_nar,
    "TXOIG": detectar_txoig,
    "USOIG": detectar_usoig,
    "TXDPS": detectar_txdps,
}

# ─────────────────────────────────────────────────────────────
#  ESCANEAR CARPETAS
# ─────────────────────────────────────────────────────────────

def escanear_carpetas(bgc_root, fecha):
    carpeta_fecha = os.path.join(bgc_root, fecha)
    if not os.path.exists(carpeta_fecha):
        print(f"  ERROR: No existe la carpeta {carpeta_fecha}")
        return []

    resultados = []
    carpetas_cg = sorted([
        d for d in os.listdir(carpeta_fecha)
        if os.path.isdir(os.path.join(carpeta_fecha, d))
    ])
    print(f"       {len(carpetas_cg)} carpetas encontradas.")

    for carpeta in carpetas_cg:
        ruta_cg = os.path.join(carpeta_fecha, carpeta)
        partes   = carpeta.split("_", 1)
        apellido = partes[0].title() if len(partes) > 0 else carpeta
        nombre   = partes[1].title() if len(partes) > 1 else ""

        resultado = {
            "Carpeta":    carpeta,
            "Last Name":  apellido,
            "First Name": nombre,
        }

        # Buscar PDFs por plataforma
        pdfs_encontrados = {}
        try:
            archivos = os.listdir(ruta_cg)
            for archivo in archivos:
                if archivo.endswith(".pdf"):
                    for plat in PLATAFORMAS:
                        if f"_AnnualBGC_{plat}" in archivo:
                            pdfs_encontrados[plat] = os.path.join(ruta_cg, archivo)
        except Exception as e:
            print(f"  ! Error leyendo {carpeta}: {e}")

        # Detectar resultado por plataforma
        for plat in PLATAFORMAS:
            if plat in pdfs_encontrados:
                texto = leer_pdf(pdfs_encontrados[plat])
                resultado[plat] = DETECTORES[plat](texto)
            else:
                resultado[plat] = "FALTA"

        hits = [p for p in PLATAFORMAS if resultado.get(p) == "HIT"]
        resultado["Novedad"]         = "SI" if hits else "NO"
        resultado["Plataformas_HIT"] = ", ".join(hits) if hits else ""
        resultados.append(resultado)

    return resultados

# ─────────────────────────────────────────────────────────────
#  GENERAR EXCEL
# ─────────────────────────────────────────────────────────────

def generar_excel(resultados, bgc_root, fecha):
    ruta_excel = os.path.join(bgc_root, f"{fecha}_BGC_Auditoria.xlsx")
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # ── Hoja Auditoria Completa ──────────────────────────────
    ws = wb.create_sheet("Auditoria Completa")
    cols = ["#", "Last Name", "First Name",
            "CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS",
            "Novedad", "Plataformas HIT"]

    for i, c in enumerate(cols, 1):
        cell = ws.cell(1, i, c)
        cell.font      = bw()
        cell.fill      = fill(C_HEADER)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border    = border()
    ws.row_dimensions[1].height = 22

    for idx, r in enumerate(resultados, 1):
        data = [idx, r["Last Name"], r["First Name"],
                r.get("CBC","FALTA"), r.get("EMR","FALTA"),
                r.get("NAR","FALTA"), r.get("TXOIG","FALTA"),
                r.get("USOIG","FALTA"), r.get("TXDPS","FALTA"),
                r["Novedad"], r["Plataformas_HIT"]]

        for j, val in enumerate(data, 1):
            cell = ws.cell(idx + 1, j, val)
            cell.border    = border()
            cell.alignment = Alignment(horizontal="center", vertical="center")
            if val == "CLEAR":
                cell.fill = fill(C_CLEAR)
            elif val == "HIT":
                cell.fill = fill(C_HIT)
                cell.font = Font(bold=True, color=C_HIT_B)
            elif val == "FALTA":
                cell.fill = fill(C_FALTA)
            elif val == "SI":
                cell.fill = fill(C_HIT)
                cell.font = Font(bold=True, color=C_HIT_B)
            elif val == "NO":
                cell.fill = fill(C_CLEAR)
            else:
                cell.fill = fill("FFFFFF")

    ws.freeze_panes = "D2"
    for col, w in [("A",5),("B",20),("C",18),("D",10),("E",10),("F",10),
                   ("G",10),("H",10),("I",10),("J",10),("K",30)]:
        ws.column_dimensions[col].width = w

    # ── Hoja Novedades ───────────────────────────────────────
    hits_list = [r for r in resultados if r["Novedad"] == "SI"]
    ws2 = wb.create_sheet("Novedades")
    cols2 = ["#", "Last Name", "First Name", "Plataformas HIT", "Accion Tomada", "Resuelto"]
    for i, c in enumerate(cols2, 1):
        cell = ws2.cell(1, i, c)
        cell.font = bw(); cell.fill = fill(C_HEADER)
        cell.alignment = Alignment(horizontal="center"); cell.border = border()
    ws2.row_dimensions[1].height = 22

    if hits_list:
        for idx, r in enumerate(hits_list, 1):
            data2 = [idx, r["Last Name"], r["First Name"],
                     r["Plataformas_HIT"], "", ""]
            for j, val in enumerate(data2, 1):
                cell = ws2.cell(idx+1, j, val)
                cell.fill   = fill(C_HIT)
                cell.border = border()
                cell.alignment = Alignment(vertical="center")
    else:
        c = ws2.cell(2, 1, "Todos los CGs estan CLEAR — sin novedades")
        c.fill = fill(C_CLEAR)
        c.font = Font(bold=True)

    for col, w in [("A",5),("B",20),("C",18),("D",25),("E",35),("F",12)]:
        ws2.column_dimensions[col].width = w

    # ── Hoja Resumen ─────────────────────────────────────────
    ws3 = wb.create_sheet("Resumen")
    total      = len(resultados)
    total_ok   = len([r for r in resultados if r["Novedad"] == "NO"])
    total_hit  = len(hits_list)
    total_falt = len([r for r in resultados
                      if any(r.get(p) == "FALTA" for p in PLATAFORMAS)])

    ws3.merge_cells("A1:D1")
    c = ws3["A1"]
    c.value     = f"BGC Auditoria {fecha} — Right at Home Austin West"
    c.fill      = fill(C_HEADER)
    c.font      = Font(bold=True, size=13, color="FFFFFF")
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws3.row_dimensions[1].height = 28

    resumen_data = [
        ("Total CGs procesados", total,      "DEEAF1"),
        ("CLEAR - Sin novedades", total_ok,  C_CLEAR),
        ("HIT - Con novedades",  total_hit,  C_HIT),
        ("Con archivos faltantes", total_falt, C_FALTA),
    ]
    for i, (label, val, color) in enumerate(resumen_data, 2):
        ws3.cell(i, 1, label).font  = Font(bold=True)
        ws3.cell(i, 1).fill         = fill(color)
        ws3.cell(i, 1).border       = border()
        ws3.cell(i, 2, val).fill    = fill(color)
        ws3.cell(i, 2).border       = border()
        ws3.cell(i, 2).alignment    = Alignment(horizontal="center")
        ws3.cell(i, 2).font         = Font(bold=True)

    ws3.cell(7, 1, "Por plataforma:").font = Font(bold=True)
    for i, plat in enumerate(PLATAFORMAS, 8):
        clears = len([r for r in resultados if r.get(plat) == "CLEAR"])
        hits_p = len([r for r in resultados if r.get(plat) == "HIT"])
        faltas = len([r for r in resultados if r.get(plat) == "FALTA"])
        ws3.cell(i, 1, plat).font  = Font(bold=True)
        ws3.cell(i, 1).border      = border()
        ws3.cell(i, 2, f"CLEAR: {clears}").fill  = fill(C_CLEAR)
        ws3.cell(i, 2).border      = border()
        ws3.cell(i, 3, f"HIT: {hits_p}").fill    = fill(C_HIT) if hits_p else fill(C_CLEAR)
        ws3.cell(i, 3).border      = border()
        ws3.cell(i, 4, f"FALTA: {faltas}").fill  = fill(C_FALTA) if faltas else fill(C_CLEAR)
        ws3.cell(i, 4).border      = border()

    for col, w in [("A",28),("B",14),("C",12),("D",14)]:
        ws3.column_dimensions[col].width = w

    wb.save(ruta_excel)
    return ruta_excel

# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

def main():
    print(f"\n{'='*65}")
    print(f"  BGC Auditoria — Right at Home Austin West")
    print(f"  Fecha: {FECHA}")
    print(f"{'='*65}\n")

    print(f"[1/2] Escaneando carpetas en: {BGC_ROOT}\\{FECHA}\\")
    resultados = escanear_carpetas(BGC_ROOT, FECHA)
    if not resultados:
        print("  No se encontraron carpetas para procesar.")
        return

    hits      = [r for r in resultados if r["Novedad"] == "SI"]
    sin_hits  = [r for r in resultados if r["Novedad"] == "NO"]
    con_falta = [r for r in resultados
                 if any(r.get(p) == "FALTA" for p in PLATAFORMAS)]

    print(f"\n       Total CGs:          {len(resultados)}")
    print(f"       CLEAR:              {len(sin_hits)}")
    print(f"       HIT (novedades):    {len(hits)}")
    print(f"       Con archivos falta: {len(con_falta)}")

    if hits:
        print(f"\n       CGs con novedades:")
        for r in hits:
            print(f"         - {r['Last Name']}, {r['First Name']} -> {r['Plataformas_HIT']}")

    print(f"\n[2/2] Generando Excel de auditoria...")
    ruta_excel = generar_excel(resultados, BGC_ROOT, FECHA)
    print(f"       Guardado: {ruta_excel}")

    print(f"\n{'='*65}")
    print(f"  Auditoria completa.")
    print(f"  -> Excel: {FECHA}_BGC_Auditoria.xlsx")
    if hits:
        print(f"  -> {len(hits)} CG(s) con novedades — ver hoja 'Novedades'")
    else:
        print(f"  -> Sin novedades — todos CLEAR")
    print(f"  -> Siguiente: bgc_04_upload_wellsky.py")
    print(f"{'='*65}\n")

if __name__ == "__main__":
    main()
