"""
BGC Preparation Script — Right at Home Austin West
====================================================
Script 1 de 4: Preparación del Background Check Anual

Qué hace:
  1. Lee el documento BGC anual (hoja "Caregivers")
     Formato: Last Name | First Name | SSN | Birth Date | DL
  2. Valida y limpia los datos
  3. Crea carpetas en: C:\BGC\FECHA\APELLIDO_NOMBRE\
  4. Genera Excel de trabajo con:
       - Hoja "Resumen"          → conteos y estado
       - Hoja "Tracking del Dia" → todos los CGs con columnas por plataforma
       - Hoja "Caregivers"       → todos los CGs con datos completos para los flujos PAD

Formato esperado del input (hoja "Caregivers"):
  Last Name | First Name | SSN | Birth Date | DL
  SSN: XXX-XX-XXXX   Birth Date: fecha Excel o YYYY-MM-DD   DL: 7-8 dígitos

Uso:
  1. Guardar el Excel de caregivers en C:\BGC\
  2. python bgc_01_preparacion.py

Requisitos:
  pip install pandas openpyxl

Autor: Angel Pabuence — Right at Home Austin West
"""

import os, re
from datetime import date
import pandas as pd
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
import openpyxl

# ─────────────────────────────────────────────────────────────
#  CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────

BGC_INPUT   = r"C:\BGC\Annual Background Check Data 2026 - Employees Personal Info.xlsx"
SHEET_INPUT = "Caregivers"
PLATAFORMAS = ["CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS"]

# ─────────────────────────────────────────────────────────────
#  AUTO-DETECT OUTPUT ROOT POR USUARIO DE PC
# ─────────────────────────────────────────────────────────────

def _get_onedrive_root(username):
    """Retorna la ruta de OneDrive BGC_Anual para un usuario dado."""
    onedrive = f"C:\\Users\\{username}\\OneDrive - Right At Home"
    RUTAS = {
        "a.pabuence": os.path.join(onedrive, "BGC_Anual"),
        "angel":      os.path.join(onedrive, "BGC_Anual"),
        "danny":      os.path.join(onedrive, "Angel Pabuence's files - BGC_Anual"),
        "d.tobon":    os.path.join(onedrive, "Angel Pabuence's files - BGC_Anual"),
    }
    return RUTAS.get(username.lower())

# Todos los PCs — para generar WorkBooks con rutas personalizadas
ALL_PCS = {
    "a.pabuence": _get_onedrive_root("a.pabuence"),
    "angel":      _get_onedrive_root("angel"),
    "danny":      _get_onedrive_root("danny"),
    "d.tobon":    _get_onedrive_root("d.tobon"),
}

import getpass as _gp
OUTPUT_ROOT = _get_onedrive_root(_gp.getuser()) or list(ALL_PCS.values())[0]

# ─────────────────────────────────────────────────────────────
#  HELPERS DE FORMATO
# ─────────────────────────────────────────────────────────────

def fill(h):  return PatternFill("solid", fgColor=h)
def bw():     return Font(bold=True, color="FFFFFF")
def border():
    s = Side(style="thin", color="BFBFBF")
    return Border(left=s, right=s, top=s, bottom=s)

def header_row(ws, cols, color="1F4E79"):
    for i, c in enumerate(cols, 1):
        cell = ws.cell(1, i, c)
        cell.font      = bw()
        cell.fill      = fill(color)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border    = border()
    ws.row_dimensions[1].height = 22

def set_col_widths(ws, width_map):
    for col, w in width_map.items():
        ws.column_dimensions[col].width = w

# ─────────────────────────────────────────────────────────────
#  HELPERS DE DATOS
# ─────────────────────────────────────────────────────────────

def limpiar(t):
    if pd.isna(t): return ""
    t = re.sub(r'[\\/*?:"<>|,]', "", str(t).strip())
    return re.sub(r'\(.*?\)', "", t).strip()

def ssn_fmt(ssn):
    if pd.isna(ssn): return ""
    s = str(ssn).strip()
    digits = s.replace("-", "").replace(" ", "")
    if len(digits) == 9 and "-" not in s:
        return f"{digits[:3]}-{digits[3:5]}-{digits[5:]}"
    return s

def ssn_digits(ssn):
    if pd.isna(ssn): return ""
    return str(ssn).replace("-", "").replace(" ", "").strip()

def ssn_u4(ssn):
    d = ssn_digits(ssn)
    return d[-4:] if len(d) >= 4 else d

def dob_fmt(dob):
    if pd.isna(dob): return ""
    try:    return pd.to_datetime(str(dob).strip()).strftime("%m/%d/%Y")
    except: return str(dob).strip()

def dob_parts(dob):
    if pd.isna(dob): return "", "", ""
    try:
        dt = pd.to_datetime(str(dob).strip())
        return str(dt.year), str(dt.month), str(dt.day)
    except: return "", "", ""

def dl_fmt(dl):
    if pd.isna(dl): return ""
    s = str(dl).strip()
    if "." in s: s = s.split(".")[0]
    return ("0" + s) if (s.isdigit() and len(s) == 7) else s

def detectar_problemas(row):
    p = []
    if not dob_fmt(row.get("Birth Date", "")): p.append("Sin DOB")
    d = ssn_digits(row.get("SSN", ""))
    if not d:           p.append("Sin SSN")
    elif len(d) != 9:   p.append(f"SSN {len(d)} dígitos")
    if not limpiar(row.get("Last Name", "")):  p.append("Sin apellido")
    if not limpiar(row.get("First Name", "")): p.append("Sin nombre")
    if not dl_fmt(row.get("DL", "")):          p.append("Sin DL")
    return p

def nombre_carpeta(last, first):
    a = limpiar(last).upper().replace(" ", "_")
    n = limpiar(first).upper().replace(" ", "_")
    return f"{a}_{n}"

def archivo_base(last, fecha):
    a = limpiar(last).title().replace(" ", "")
    return f"{fecha}_{a}_AnnualBGC"

# ─────────────────────────────────────────────────────────────
#  CREAR CARPETAS
# ─────────────────────────────────────────────────────────────

def crear_carpetas(df, output_root, fecha):
    creadas, errores = 0, []
    for _, row in df.iterrows():
        carpeta = nombre_carpeta(row["Last Name"], row["First Name"])
        ruta    = os.path.join(output_root, fecha, carpeta)
        try:
            os.makedirs(ruta, exist_ok=True)
            creadas += 1
        except Exception as e:
            errores.append(f"{carpeta}: {e}")
    return creadas, errores

# ─────────────────────────────────────────────────────────────
#  HOJAS DEL EXCEL
# ─────────────────────────────────────────────────────────────

def hoja_resumen(wb, df, fecha):
    ws = wb.create_sheet("Resumen")
    ws.merge_cells("A1:E1")
    c = ws["A1"]
    c.value     = f"Background Check Anual {fecha} — Right at Home Austin West"
    c.fill      = fill("1F4E79")
    c.font      = Font(bold=True, size=13, color="FFFFFF")
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    for i, h in enumerate(["Total CGs", "Sin problemas", "Con problemas", "Sin DOB", "Sin DL"], 1):
        cell = ws.cell(2, i, h)
        cell.font = bw(); cell.fill = fill("2E75B6")
        cell.alignment = Alignment(horizontal="center"); cell.border = border()

    probs   = df.apply(lambda r: len(detectar_problemas(r)) > 0, axis=1).sum()
    sin_dob = df["Birth Date"].isna().sum()
    sin_dl  = df["DL"].isna().sum()

    for i, v in enumerate([len(df), int(len(df)-probs), int(probs), int(sin_dob), int(sin_dl)], 1):
        c = ws.cell(3, i, v)
        c.fill      = fill("FFF2CC") if (i > 1 and v > 0) else fill("DEEAF1")
        c.border    = border()
        c.alignment = Alignment(horizontal="center")
        c.font      = Font(bold=True)

    set_col_widths(ws, {"A": 14, "B": 16, "C": 16, "D": 12, "E": 12})


def hoja_tracking(wb, df):
    ws = wb.create_sheet("Tracking del Dia")
    cols = ["#", "Last Name", "First Name",
            "CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS",
            "Novedad", "Accion Tomada", "Listo"]
    header_row(ws, cols)
    for idx, (_, row) in enumerate(df.iterrows(), 1):
        data = [idx, str(row["Last Name"]).strip(), str(row["First Name"]).strip(),
                "", "", "", "", "", "", "", "", ""]
        for j, v in enumerate(data, 1):
            cell = ws.cell(idx + 1, j, v)
            cell.fill      = fill("DEEAF1") if idx % 2 == 0 else fill("FFFFFF")
            cell.border    = border()
            cell.alignment = Alignment(vertical="center")
    ws.freeze_panes = "C2"
    set_col_widths(ws, {"A": 5, "B": 18, "C": 16, "D": 8, "E": 8,
                        "F": 8, "G": 8, "H": 8, "I": 8, "J": 12, "K": 35, "L": 8})


def hoja_caregivers(wb, df, fecha, output_root_override=None):
    """Hoja principal — todos los CGs con datos completos para los flujos PAD."""
    ws = wb.create_sheet("Caregivers")
    cols = ["#", "Last Name", "First Name", "DOB", "DOB_Year", "DOB_Month", "DOB_Day",
            "SSN", "SSN_U4", "DL",
            "Carpeta", "Archivo_Base", "Ruta_Completa",
            "CBC", "EMR", "NAR", "TXOIG", "USOIG", "TXDPS",
            "Novedad", "Notas", "Problemas"]
    header_row(ws, cols)

    for idx, (_, row) in enumerate(df.iterrows(), 1):
        last  = str(row["Last Name"]).strip()
        first = str(row["First Name"]).strip()
        prb   = " | ".join(detectar_problemas(row))
        rf    = fill("FFF2CC") if prb else (fill("DEEAF1") if idx % 2 == 0 else fill("FFFFFF"))

        y, m, d = dob_parts(row["Birth Date"])
        carp    = nombre_carpeta(last, first)
        base    = archivo_base(last, fecha)
        _root = output_root_override if output_root_override else OUTPUT_ROOT
        ruta    = os.path.join(_root, fecha, carp)

        data = [idx, last, first,
                dob_fmt(row["Birth Date"]), y, m, d,
                ssn_fmt(row["SSN"]), ssn_u4(row["SSN"]),
                dl_fmt(row["DL"]),
                carp, base, ruta,
                "", "", "", "", "", "",
                "", "", prb]

        for j, v in enumerate(data, 1):
            cell = ws.cell(idx + 1, j, v)
            cell.fill      = rf
            cell.border    = border()
            cell.alignment = Alignment(vertical="center")

    ws.freeze_panes = "C2"
    set_col_widths(ws, {
        "A": 5,  "B": 18, "C": 16, "D": 13, "E": 9,  "F": 9,  "G": 9,
        "H": 16, "I": 9,  "J": 12, "K": 28, "L": 34, "M": 45,
        "N": 8,  "O": 8,  "P": 8,  "Q": 8,  "R": 8,  "S": 8,
        "T": 12, "U": 30, "V": 40
    })

# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

def main():
    fecha = date.today().strftime("%Y%m%d")
    print(f"\n{'='*65}")
    print(f"  BGC Preparation — Right at Home Austin West")
    print(f"  Fecha: {fecha}")
    print(f"{'='*65}\n")

    # 1. Leer documento
    print(f"[1/4] Leyendo: {BGC_INPUT}")
    try:
        df = pd.read_excel(BGC_INPUT, sheet_name=SHEET_INPUT, engine="openpyxl")
    except FileNotFoundError:
        print(f"\n  ERROR: Archivo no encontrado.\n  Verifica: {BGC_INPUT}")
        return
    except Exception as e:
        print(f"\n  ERROR: {e}"); return

    df.columns = [c.strip() for c in df.columns]
    df = df[df["Last Name"].notna() & (df["Last Name"].astype(str).str.strip() != "")]
    df = df.sort_values(["Last Name", "First Name"]).reset_index(drop=True)
    print(f"       {len(df)} caregivers cargados.\n")

    # 2. Validación
    print(f"[2/4] Validando datos:")
    con_probs = df.apply(lambda r: len(detectar_problemas(r)) > 0, axis=1).sum()
    sin_dob   = df["Birth Date"].isna().sum()
    sin_ssn   = df["SSN"].isna().sum()
    sin_dl    = df["DL"].isna().sum()
    print(f"       Sin DOB : {sin_dob}")
    print(f"       Sin SSN : {sin_ssn}")
    print(f"       Sin DL  : {sin_dl}")
    print(f"       Total con problemas: {con_probs}")
    if con_probs > 0:
        print(f"       → Ver columna 'Problemas' en la hoja Caregivers")
    print()

    # 3. Carpetas
    print(f"[3/4] Creando carpetas en: {OUTPUT_ROOT}\\{fecha}\\")
    os.makedirs(OUTPUT_ROOT, exist_ok=True)
    creadas, errores = crear_carpetas(df, OUTPUT_ROOT, fecha)
    print(f"       {creadas} carpetas creadas.")
    if errores:
        for e in errores[:5]: print(f"         ! {e}")
    print()

    # 4. Excel — un WorkBook por PC con rutas personalizadas
    print(f"[4/4] Generando WorkBooks por PC...")

    for pc_user, pc_root in ALL_PCS.items():
        if not pc_root:
            print(f"       ⚠ {pc_user}: ruta no configurada — saltando")
            continue

        wb = openpyxl.Workbook()
        wb.remove(wb.active)

        hoja_resumen(wb, df, fecha)
        hoja_tracking(wb, df)
        hoja_caregivers(wb, df, fecha, output_root_override=pc_root)

        ruta_excel = os.path.join(OUTPUT_ROOT, f"{fecha}_BGC_WorkBook_{pc_user}.xlsx")
        wb.save(ruta_excel)
        print(f"       {pc_user}: {ruta_excel}")

    print(f"\n{'='*65}")
    print(f"  ✓ Preparación completa.")
    print(f"  → Carpetas: {OUTPUT_ROOT}\\{fecha}\\")
    print(f"  → WorkBooks: un archivo por PC en {OUTPUT_ROOT}")
    print(f"  → Siguiente: Distribuir WorkBooks y correr flujos PAD")
    print(f"{'='*65}\n")

if __name__ == "__main__":
    main()
