"""
Tasks_VA_add.py
Agrega tareas a turnos VA (Complete) en WellSky segun el tipo de autorizacion
(VA HHA o VA Respite), detectada leyendo el campo Bill Rate del modal del turno.

Uso:
    python Tasks_VA_add.py --client-url "https://..." --start-date 2026-01-01 --end-date 2026-06-30
    python Tasks_VA_add.py --client-url "https://..." --year 2026 --month 1 --start-day 1 --end-day 31
"""
from __future__ import annotations

import argparse
import re
import time
from datetime import datetime, date, time as dt_time, timedelta
from typing import Optional, Tuple, List

from playwright.sync_api import sync_playwright, Page, Locator, TimeoutError as PWTimeout

# =========================
# CONFIG — EDITAR POR CLIENTE
# =========================

AUTH_RULES: dict[str, List[str]] = {
    "VA HHA": [
        "Bathing",
        "Dressing",
        "Grooming (Brush hair, Brush teeth, Comb hair)",
        "Eating",
        "Bed mobility",
        "Walking",
        "Toileting",
    ],
    
    "VA Respite": [
        "Clean Bathroom",
        "ADDITIONAL TASKS COMPLETED DURING SHIFT",
        "Verbal cueing",
        "Safety supervision"
        
    ],
}

# =========================
# SELECTORES
# =========================

MONTHS = {
    "January": 1, "February": 2, "March": 3, "April": 4,
    "May": 5, "June": 6, "July": 7, "August": 8,
    "September": 9, "October": 10, "November": 11, "December": 12,
}

S = {
    "spinner":       ".loading, .spinner, .ui-progressbar",
    "daily_care_tab":"a:has-text('Daily Care Log'), a:has-text('Daily Care Logs'), a[href*='carelog']",
    "cal_title":     ".ui-datepicker-title",
    "cal_prev":      "a.ui-datepicker-prev, span.ui-icon-circle-triangle-w",
    "cal_next":      "a.ui-datepicker-next, span.ui-icon-circle-triangle-e",
    "cal_day":       "table.ui-datepicker-calendar a.ui-state-default",
    "cal_active":    "table.ui-datepicker-calendar a.ui-state-active",
}

# Regex para detectar HHA o Respite en el rate-name del option seleccionado
RATE_HHA_RE     = re.compile(r"VA.*HHA",     re.IGNORECASE)
RATE_RESPITE_RE = re.compile(r"VA.*Respite", re.IGNORECASE)

# =========================
# UTILS
# =========================

def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_hidden(page: Page, sel: str, t: int = 6000) -> None:
    try:
        page.locator(sel).first.wait_for(state="hidden", timeout=t)
    except Exception:
        pass


def close_modal(page: Page) -> None:
    """Cierra cualquier modal/dialog abierto."""
    for _ in range(3):
        try:
            page.keyboard.press("Escape")
            time.sleep(0.3)
        except Exception:
            pass
    # Fallback: boton X del dialog
    try:
        page.locator(".ui-dialog-titlebar-close").first.click()
        time.sleep(0.3)
    except Exception:
        pass


# =========================
# CALENDARIO
# =========================

def read_cal_month_year(page: Page) -> Tuple[int, int]:
    try:
        title = page.locator(S["cal_title"]).first.inner_text(timeout=1500).strip()
        m = re.search(r"([A-Za-z]+)\s+(\d{4})", title)
        if not m:
            return 0, 0
        return MONTHS.get(m.group(1), 0), int(m.group(2))
    except Exception:
        return 0, 0


def align_calendar(page: Page, year: int, month: int) -> bool:
    for _ in range(30):
        cur_month, cur_year = read_cal_month_year(page)
        if cur_month == 0 or cur_year == 0:
            time.sleep(0.3)
            continue
        if cur_year == year and cur_month == month:
            return True
        try:
            if (cur_year, cur_month) > (year, month):
                page.locator(S["cal_prev"]).first.click()
            else:
                page.locator(S["cal_next"]).first.click()
        except Exception:
            pass
        time.sleep(0.3)
    log("WARNING: No se pudo alinear el calendario.")
    return False


def select_day(page: Page, day: int) -> bool:
    try:
        page.get_by_role("link", name=str(day), exact=True).click()
        time.sleep(0.5)
        return True
    except Exception:
        pass

    buttons = page.locator(S["cal_day"]).filter(has_text=str(day))
    if buttons.count() == 0:
        log(f"   WARNING: Dia {day} no encontrado en calendario.")
        return False

    for i in range(buttons.count()):
        b = buttons.nth(i)
        for attempt in range(3):
            try:
                if attempt == 0:
                    b.click()
                elif attempt == 1:
                    b.click(force=True)
                else:
                    b.evaluate("el => el.click()")
            except Exception:
                continue
            for _ in range(20):
                try:
                    active = page.locator(S["cal_active"]).first.inner_text(timeout=400).strip()
                    if active == str(day):
                        time.sleep(0.5)
                        wait_hidden(page, S["spinner"], 5000)
                        return True
                except Exception:
                    pass
                time.sleep(0.15)
    return False


# =========================
# PARSEO DE CARELOGS
# =========================

DT_RE = re.compile(
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))\s*-\s*"
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))"
)


def normalize_ampm(txt: str) -> str:
    return (
        txt.replace("a.m.", "AM").replace("p.m.", "PM")
           .replace("A.M.", "AM").replace("P.M.", "PM")
           .replace("a. m.", "AM").replace("p. m.", "PM")
    )


def parse_carelog_range(date_text: str) -> Tuple[Optional[datetime], Optional[datetime]]:
    txt = normalize_ampm(" ".join(date_text.split()))
    m = DT_RE.search(txt)
    if not m:
        return None, None
    start_date_s, start_time_s, end_date_s, end_time_s = m.groups()
    try:
        start_dt = datetime.strptime(f"{start_date_s} {start_time_s}", "%m/%d/%y %I:%M %p")
        end_dt   = datetime.strptime(f"{end_date_s} {end_time_s}",   "%m/%d/%y %I:%M %p")
        return start_dt, end_dt
    except ValueError:
        return None, None


# =========================
# LEER TIPO DE AUTH DEL MODAL
# =========================

def get_auth_type(page: Page, cid: str) -> Optional[str]:
    """
    Abre el modal del turno, lee el Bill Rate del change-list,
    y cierra el modal.
    Retorna 'VA HHA', 'VA Respite', o None si no es turno VA.
    """
    link = page.locator(f"#carelog_{cid}_datetime a.edit-carelog")
    try:
        link.wait_for(state="visible", timeout=5000)
        link.scroll_into_view_if_needed()
        time.sleep(0.3)
        link.click()
    except Exception as e:
        log(f"       WARNING: No se pudo abrir modal de carelog_{cid}: {e}")
        return None

    time.sleep(1.5)
    wait_hidden(page, S["spinner"], 5000)

    # Leer el change-list que siempre contiene "Bill Rate: ..."
    text = ""
    for _ in range(15):
        try:
            text = page.locator(".change-list").first.inner_text(timeout=1000)
            if "Bill Rate:" in text:
                break
        except Exception:
            pass
        time.sleep(0.3)

    log(f"       change-list text snippet: '{text[text.find('Bill Rate:'):text.find('Bill Rate:')+40] if 'Bill Rate:' in text else 'NO BILL RATE'}'")

    auth_type = None
    if RATE_HHA_RE.search(text):
        auth_type = "VA HHA"
    elif RATE_RESPITE_RE.search(text):
        auth_type = "VA Respite"
    else:
        log(f"       INFO: No se encontro VA HHA ni VA Respite en change-list.")

    close_modal(page)
    time.sleep(0.5)
    wait_hidden(page, S["spinner"], 4000)
    return auth_type

def open_carelog_header(page: Page, cid: str) -> bool:
    """Abre el h3 del turno si no esta ya activo."""
    try:
        cls = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=2000) or ""
        if "ui-state-active" in cls:
            log(f"       Turno {cid} ya esta abierto.")
            return True
    except Exception:
        pass

    h3 = page.locator(f"h3#carelog_{cid}")
    for attempt in range(4):
        try:
            if attempt == 0:
                h3.click()
            elif attempt == 1:
                h3.click(force=True)
            elif attempt == 2:
                h3.dispatch_event("click")
            else:
                h3.evaluate("el => el.click()")
        except Exception as e:
            log(f"       WARNING: click h3 attempt {attempt}: {e}")
            continue

        time.sleep(0.4)
        wait_hidden(page, S["spinner"], 3000)
        try:
            cls = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=1000) or ""
            if "ui-state-active" in cls:
                return True
        except Exception:
            pass

    log(f"       ERROR: No se pudo abrir turno {cid}.")
    return False


# =========================
# AGREGAR TAREAS AL PANEL
# =========================

def add_tasks_to_panel(panel: Locator, page: Page, end_dt: datetime, tasks_to_add: List[str]) -> int:
    """
    Agrega las tareas faltantes al panel segun la lista del tipo de auth.
    Hora = 5 minutos antes del fin del turno.
    """
    added = 0
    target_dt = end_dt - timedelta(minutes=5)
    target_time_str = target_dt.strftime("%I:%M %p")
    log(f"       Hora objetivo: {target_time_str} (5 min antes de fin)")

    try:
        existing_titles = panel.locator(".task_title a.link_no_color").all_text_contents()
    except Exception:
        existing_titles = []
    normalized = [t.strip().lower() for t in existing_titles]
    log(f"       Tareas actuales: {len(existing_titles)}")

    for task_title in tasks_to_add:
        if task_title.lower() in normalized:
            log(f"       SKIP: '{task_title}' ya existe.")
            continue

        log(f"       AGREGAR: '{task_title}'")

        # Clic en "+ Add Task"
        clicked_add = False
        for attempt in range(4):
            try:
                add_btn = panel.locator("a[ng-click^='add_task']").first
                if attempt == 0:
                    add_btn.click()
                elif attempt == 1:
                    add_btn.click(force=True)
                elif attempt == 2:
                    add_btn.dispatch_event("click")
                else:
                    add_btn.evaluate("el => el.click()")
                clicked_add = True
                break
            except Exception as e:
                log(f"       WARNING add_task click attempt {attempt}: {e}")

        if not clicked_add:
            log(f"       ERROR: No se pudo abrir formulario para '{task_title}'.")
            continue

        time.sleep(0.4)

        # Rellenar hora
        try:
            time_input = page.get_by_role("textbox", name="HH:mm AM")
            time_input.wait_for(state="visible", timeout=3000)
            time_input.click()
            time_input.press("Control+a")
            time_input.fill(target_time_str)
            time_input.press("Tab")
            time.sleep(0.3)
        except Exception as e:
            log(f"       WARNING: No se pudo llenar hora: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Rellenar título
        try:
            title_input = page.locator('input[name="tasktitle"]')
            title_input.wait_for(state="visible", timeout=2000)
            title_input.click()
            title_input.fill(task_title)
            title_input.press("Tab")
            time.sleep(0.2)
        except Exception as e:
            log(f"       WARNING: No se pudo llenar titulo: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Esperar a que Angular habilite Save
        save_btn = page.locator("button[ng-click='save()']")
        enabled = False
        for _ in range(20):
            try:
                cls = save_btn.get_attribute("class") or ""
                if "ui-state-disabled" not in cls:
                    enabled = True
                    break
            except Exception:
                pass
            time.sleep(0.15)

        if not enabled:
            log(f"       WARNING: Save sigue deshabilitado para '{task_title}', se omite.")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Guardar
        saved = False
        for attempt in range(3):
            try:
                if attempt == 0:
                    save_btn.click()
                elif attempt == 1:
                    save_btn.click(force=True)
                else:
                    save_btn.evaluate("el => el.click()")
                saved = True
                break
            except Exception as e:
                log(f"       WARNING Save attempt {attempt}: {e}")
                time.sleep(0.3)

        if not saved:
            log(f"       ERROR: No se pudo guardar '{task_title}'.")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        time.sleep(0.6)
        wait_hidden(page, S["spinner"], 4000)
        added += 1
        normalized.append(task_title.lower())

    return added


# =========================
# RECOLECTAR TURNOS DEL DIA
# =========================

def collect_carelog_ids(page: Page, year: int, month: int, day: int) -> list:
    """
    Recorre los h3[id^='carelog_'] del dia.
    Solo incluye turnos (Complete).
    Retorna lista de (cid, start_dt, end_dt).
    """
    h3s = page.locator("h3[id^='carelog_']")
    total = h3s.count()
    log(f"    Turnos en el dia: {total}")

    result = []
    for i in range(total):
        h3 = h3s.nth(i)
        try:
            cid = (h3.get_attribute("id") or "").replace("carelog_", "")
            if not cid:
                continue
        except Exception:
            continue

        # Solo (Complete)
        try:
            h3_text = h3.inner_text(timeout=1000).lower()
            if "(complete)" not in h3_text:
                log(f"    SKIP no-complete (carelog_{cid})")
                continue
        except Exception:
            pass

        # Leer fecha — abrir si es necesario
        date_text = None
        try:
            date_text = page.locator(f"#carelog_{cid}_datetime a.edit-carelog").inner_text(timeout=1000)
        except Exception:
            pass

        if not date_text:
            if open_carelog_header(page, cid):
                try:
                    date_text = page.locator(f"#carelog_{cid}_datetime a.edit-carelog").inner_text(timeout=2000)
                except Exception:
                    log(f"    WARNING: No se pudo leer fecha de carelog_{cid}.")
                    continue
            else:
                continue

        start_dt, end_dt = parse_carelog_range(date_text)
        if not start_dt or not end_dt:
            log(f"    WARNING: No se pudo parsear carelog_{cid}.")
            continue

        # Sin restriccion de hora — aplica a todos los turnos (Complete) del dia
        if start_dt.date() == date(year, month, day):
            log(f"    OK (carelog_{cid}): "
                f"{start_dt.strftime('%m/%d/%y %I:%M %p')} - {end_dt.strftime('%m/%d/%y %I:%M %p')}")
            result.append((cid, start_dt, end_dt))
        else:
            log(f"    SKIP fecha no coincide (carelog_{cid})")

    return result


# =========================
# PROCESO DIA
# =========================

def process_day(page: Page, year: int, month: int, day: int) -> int:
    log(f"[Day {year}-{month:02d}-{day:02d}] Procesando...")

    if not select_day(page, day):
        log(f"    WARNING: No se pudo seleccionar el dia {day}.")
        return 0

    time.sleep(1.5)

    if page.locator("h3[id^='carelog_']").count() == 0:
        log("    Sin care logs para este dia.")
        return 0

    carelogs = collect_carelog_ids(page, year, month, day)

    if not carelogs:
        log("    Sin turnos Complete para este dia.")
        return 0

    day_added = 0

    for cid, start_dt, end_dt in carelogs:
        log(f"    Procesando carelog_{cid}...")

        # Abrir el acordeon del turno
        if not open_carelog_header(page, cid):
            log(f"       ERROR: No se pudo abrir carelog_{cid}, se omite.")
            continue

        time.sleep(0.5)

        # Leer tipo de auth desde el modal
        auth_type = get_auth_type(page, cid)

        if not auth_type:
            log(f"       SKIP carelog_{cid}: no es turno VA o no se pudo determinar auth.")
            continue

        log(f"       Auth detectada: {auth_type}")

        tasks_to_add = AUTH_RULES.get(auth_type, [])
        if not tasks_to_add:
            log(f"       INFO: No hay tareas configuradas para '{auth_type}' en AUTH_RULES.")
            continue

        # Re-abrir el acordeon (el modal puede haberlo colapsado)
        if not open_carelog_header(page, cid):
            log(f"       ERROR: No se pudo re-abrir carelog_{cid} tras cerrar modal.")
            continue

        time.sleep(0.5)

        # Localizar panel de tareas
        panel = page.locator("div.tasks").filter(
            has=page.locator(f"#carelog_{cid}_datetime")
        )

        if panel.count() == 0:
            log(f"       WARNING: No se encontro panel de tareas para carelog_{cid}.")
            continue

        day_added += add_tasks_to_panel(panel.nth(0), page, end_dt, tasks_to_add)

    return day_added


# =========================
# ITERAR FECHAS
# =========================

def iter_dates(start_date: date, end_date: date):
    current = start_date
    while current <= end_date:
        yield current.year, current.month, current.day
        current += timedelta(days=1)


# =========================
# MAIN
# =========================

def main():
    parser = argparse.ArgumentParser(
        description="Agregar tareas a turnos VA (HHA/Respite) en WellSky segun autorizacion."
    )
    parser.add_argument("--client-url", required=True, help="URL del cliente en WellSky.")
    parser.add_argument("--headful", action="store_true", help="Mostrar navegador.")

    parser.add_argument("--start-date", help="Fecha inicial (YYYY-MM-DD).")
    parser.add_argument("--end-date",   help="Fecha final   (YYYY-MM-DD).")

    parser.add_argument("--year",      type=int)
    parser.add_argument("--month",     type=int)
    parser.add_argument("--start-day", type=int)
    parser.add_argument("--end-day",   type=int)

    args = parser.parse_args()

    if args.start_date and args.end_date:
        try:
            start_date = datetime.strptime(args.start_date, "%Y-%m-%d").date()
            end_date   = datetime.strptime(args.end_date,   "%Y-%m-%d").date()
        except ValueError as e:
            log(f"ERROR: Formato de fecha invalido: {e}")
            return
    elif args.year and args.month and args.start_day and args.end_day:
        start_date = date(args.year, args.month, args.start_day)
        end_date   = date(args.year, args.month, args.end_day)
    else:
        parser.error("Usa --start-date/--end-date o --year/--month/--start-day/--end-day")
        return

    if end_date < start_date:
        log("ERROR: --end-date no puede ser menor que --start-date.")
        return

    log("Iniciando: Tasks_VA_add...")
    log(f"Rango: {start_date.isoformat()} -> {end_date.isoformat()}")
    log(f"Auth rules configuradas: {list(AUTH_RULES.keys())}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not args.headful)
        context = browser.new_context(
            storage_state="login_state.json",
            viewport={"width": 1400, "height": 950},
        )
        page = context.new_page()
        page.set_default_timeout(25000)

        page.goto(args.client_url, wait_until="domcontentloaded")
        wait_hidden(page, S["spinner"], 8000)

        # Navegar a Daily Care Logs
        nav_ok = False
        for link_name in ("Daily Care Logs", "Daily Care Log"):
            try:
                page.get_by_role("link", name=link_name).click()
                nav_ok = True
                break
            except Exception:
                pass
        if not nav_ok:
            try:
                page.locator(S["daily_care_tab"]).first.click()
                nav_ok = True
            except Exception:
                pass
        if not nav_ok:
            log("ERROR: No se encontro el enlace 'Daily Care Logs'.")
            browser.close()
            return

        wait_hidden(page, S["spinner"], 8000)
        time.sleep(1.5)

        align_calendar(page, start_date.year, start_date.month)

        total_added   = 0
        total_days    = 0
        current_month = (start_date.year, start_date.month)

        for year, month, day in iter_dates(start_date, end_date):
            if (year, month) != current_month:
                log(f"--- Cambiando a {year}-{month:02d} ---")
                align_calendar(page, year, month)
                current_month = (year, month)
                time.sleep(0.5)

            try:
                added = process_day(page, year, month, day)
                total_added += added
                total_days  += 1
            except Exception as e:
                log(f"    ERROR procesando {year}-{month:02d}-{day:02d}: {e}")

        log("COMPLETADO.")
        log(f"Resumen -> dias procesados:{total_days} | tareas agregadas:{total_added}")

        try:
            context.storage_state(path="login_state.json")
        except Exception:
            pass
        browser.close()


if __name__ == "__main__":
    main()
