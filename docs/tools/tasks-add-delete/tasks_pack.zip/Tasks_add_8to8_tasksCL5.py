"""
Tasks_add_8to8_tasks.py  — v2.0 (robust)
Agrega tareas estandar a Daily Care Logs en WellSky (turnos que empiezan >= 8am y < 8pm).

Fixes vs v1:
- align_calendar: usa selectores dobles (prev/next) mas robustos
- add_tasks_to_panel: manejo de errores en cada paso del modal
- process_day: re-query de carelogs si el DOM cambia
- Timeouts explícitos en todos los locators
- Try/except granulares en cada operacion de UI
- Resumen detallado al final
"""
from __future__ import annotations

import argparse
import re
import time
from datetime import datetime, date, time as dt_time, timedelta
from typing import Optional, Tuple

from playwright.sync_api import sync_playwright, Page, Locator, TimeoutError as PWTimeout

# =========================
# CONFIG
# =========================

TASKS_TO_ADD = [
    "Grooming",
    "Bathing",
    "Dressing",
    "Eating (Meal prep)",
    "Toileting",
    "Transfers"
]

MONTHS = {
    "January": 1, "February": 2, "March": 3, "April": 4,
    "May": 5, "June": 6, "July": 7, "August": 8,
    "September": 9, "October": 10, "November": 11, "December": 12,
}

S = {
    "spinner": ".loading, .spinner, .ui-progressbar",
    "daily_care_tab": "a:has-text('Daily Care Log'), a:has-text('Daily Care Logs'), a[href*='carelog']",
    "cal_title": ".ui-datepicker-title",
    "cal_prev": "a.ui-datepicker-prev, span.ui-icon-circle-triangle-w",
    "cal_next": "a.ui-datepicker-next, span.ui-icon-circle-triangle-e",
    "cal_day": "table.ui-datepicker-calendar a.ui-state-default",
    "cal_active": "table.ui-datepicker-calendar a.ui-state-active",
}


# =========================
# UTILS
# =========================

def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_hidden(page: Page, sel: str, t: int = 6000) -> None:
    try:
        page.locator(sel).first.wait_for(state="hidden", timeout=t)
    except Exception:
        pass


# =========================
# CALENDARIO
# =========================

def read_cal_month_year(page: Page) -> Tuple[int, int]:
    try:
        title = page.locator(S["cal_title"]).first.inner_text(timeout=1500).strip()
        m = re.search(r"([A-Za-z]+)\s+(\d{4})", title)
        if not m:
            return 0, 0
        return MONTHS.get(m.group(1), 0), int(m.group(2))
    except Exception:
        return 0, 0


def align_calendar(page: Page, year: int, month: int) -> bool:
    """Mueve el mini-calendario hasta quedar en year/month."""
    for _ in range(30):
        cur_month, cur_year = read_cal_month_year(page)
        if cur_month == 0 or cur_year == 0:
            time.sleep(0.3)
            continue
        if cur_year == year and cur_month == month:
            return True
        try:
            if (cur_year, cur_month) > (year, month):
                page.locator(S["cal_prev"]).first.click()
            else:
                page.locator(S["cal_next"]).first.click()
        except Exception:
            pass
        time.sleep(0.3)
    log("WARNING: No se pudo alinear el calendario.")
    return False


def select_day(page: Page, day: int) -> bool:
    """Selecciona un día en el calendario con fallbacks."""
    try:
        page.get_by_role("link", name=str(day), exact=True).click()
        time.sleep(0.5)
        return True
    except Exception:
        pass

    buttons = page.locator(S["cal_day"]).filter(has_text=str(day))
    if buttons.count() == 0:
        log(f"   WARNING: Dia {day} no encontrado en calendario.")
        return False

    for i in range(buttons.count()):
        b = buttons.nth(i)
        for attempt in range(3):
            try:
                if attempt == 0:
                    b.click()
                elif attempt == 1:
                    b.click(force=True)
                else:
                    b.evaluate("el => el.click()")
            except Exception:
                continue

            for _ in range(20):
                try:
                    active = page.locator(S["cal_active"]).first.inner_text(timeout=400).strip()
                    if active == str(day):
                        time.sleep(0.5)
                        wait_hidden(page, S["spinner"], 5000)
                        return True
                except Exception:
                    pass
                time.sleep(0.15)

    return False


# =========================
# PARSEO DE CARELOGS
# =========================

DT_RE = re.compile(
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))\s*-\s*"
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))"
)


def normalize_ampm(txt: str) -> str:
    return (
        txt.replace("a.m.", "AM").replace("p.m.", "PM")
           .replace("A.M.", "AM").replace("P.M.", "PM")
           .replace("a. m.", "AM").replace("p. m.", "PM")
    )


def parse_carelog_range(date_text: str) -> Tuple[Optional[datetime], Optional[datetime]]:
    txt = normalize_ampm(" ".join(date_text.split()))
    m = DT_RE.search(txt)
    if not m:
        return None, None
    start_date_s, start_time_s, end_date_s, end_time_s = m.groups()
    try:
        start_dt = datetime.strptime(f"{start_date_s} {start_time_s}", "%m/%d/%y %I:%M %p")
        end_dt = datetime.strptime(f"{end_date_s} {end_time_s}", "%m/%d/%y %I:%M %p")
        return start_dt, end_dt
    except ValueError:
        return None, None


def carelog_matches_rule(start_dt: datetime, year: int, month: int, day: int) -> bool:
    """Regla: inicio = día objetivo, hora >= 08:00 y < 20:00."""
    target_date = date(year, month, day)
    if start_dt.date() != target_date:
        return False
    start_t: dt_time = start_dt.time()
    return dt_time(8, 0) <= start_t < dt_time(20, 0)


# =========================
# AGREGAR TAREAS AL PANEL
# =========================

def add_tasks_to_panel(panel: Locator, page: Page, end_dt: datetime) -> int:
    """
    Agrega las tareas faltantes al panel de un carelog.
    Hora = 5 minutos antes del fin del turno.
    """
    added = 0
    target_dt = end_dt - timedelta(minutes=5)
    target_time_str = target_dt.strftime("%I:%M %p")
    log(f"       Hora objetivo: {target_time_str} (5 min antes de fin)")

    try:
        existing_titles = panel.locator(".task_title a.link_no_color").all_text_contents()
    except Exception:
        existing_titles = []
    normalized = [t.strip().lower() for t in existing_titles]
    log(f"       Tareas actuales: {len(existing_titles)}")

    for task_title in TASKS_TO_ADD:
        if task_title.lower() in normalized:
            log(f"       SKIP: '{task_title}' ya existe.")
            continue

        log(f"       AGREGAR: '{task_title}'")

        # Clic en "+ Add Task"
        clicked_add = False
        for attempt in range(4):
            try:
                add_btn = panel.locator("a[ng-click^='add_task']").first
                if attempt == 0:
                    add_btn.click()
                elif attempt == 1:
                    add_btn.click(force=True)
                elif attempt == 2:
                    add_btn.dispatch_event("click")
                else:
                    add_btn.evaluate("el => el.click()")
                clicked_add = True
                break
            except Exception as e:
                log(f"       WARNING add_task click attempt {attempt}: {e}")

        if not clicked_add:
            log(f"       ERROR: No se pudo abrir formulario de tarea para '{task_title}'.")
            continue

        time.sleep(0.4)

        # Rellenar hora
        try:
            time_input = page.get_by_role("textbox", name="HH:mm AM")
            time_input.wait_for(state="visible", timeout=3000)
            time_input.click()
            time_input.press("Control+a")
            time_input.fill(target_time_str)
            time_input.press("Tab")  # trigger Angular validation
            time.sleep(0.3)
        except Exception as e:
            log(f"       WARNING: No se pudo llenar hora: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Rellenar título
        try:
            title_input = page.locator('input[name="tasktitle"]')
            title_input.wait_for(state="visible", timeout=2000)
            title_input.click()
            title_input.fill(task_title)
            title_input.press("Tab")  # trigger Angular validation
            time.sleep(0.2)
        except Exception as e:
            log(f"       WARNING: No se pudo llenar titulo: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Esperar a que Angular habilite el boton Save (ng-disabled se quita cuando el form es valido)
        save_btn = page.locator("button[ng-click='save()']")
        enabled = False
        for _ in range(20):
            try:
                cls = save_btn.get_attribute("class") or ""
                if "ui-state-disabled" not in cls:
                    enabled = True
                    break
            except Exception:
                pass
            time.sleep(0.15)
        if not enabled:
            log(f"       WARNING: Save sigue deshabilitado para '{task_title}', se omite.")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        # Guardar
        saved = False
        for attempt in range(3):
            try:
                if attempt == 0:
                    save_btn.click()
                elif attempt == 1:
                    save_btn.click(force=True)
                else:
                    save_btn.evaluate("el => el.click()")
                saved = True
                break
            except Exception as e:
                log(f"       WARNING Save attempt {attempt}: {e}")
                time.sleep(0.3)

        if not saved:
            log(f"       ERROR: No se pudo guardar '{task_title}'.")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            continue

        time.sleep(0.6)
        wait_hidden(page, S["spinner"], 4000)
        added += 1
        normalized.append(task_title.lower())

    return added


# =========================
# PROCESO DIA
# =========================

def open_carelog_header(page: Page, cid: str) -> bool:
    """
    Abre el header de un turno especifico si no esta ya abierto.
    WellSky es acordeon exclusivo: solo un panel abierto a la vez.
    Abierto = h3#carelog_{cid} tiene clase ui-state-active.
    """
    try:
        header_class = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=2000) or ""
        if "ui-state-active" in header_class:
            log(f"       Turno {cid} ya esta abierto.")
            return True
    except Exception:
        pass

    # Hacer clic directo en el h3 (no en el <a> interno para evitar timeout por texto)
    header_h3 = page.locator(f"h3#carelog_{cid}")
    for attempt in range(4):
        try:
            if attempt == 0:
                header_h3.click()
            elif attempt == 1:
                header_h3.click(force=True)
            elif attempt == 2:
                header_h3.dispatch_event("click")
            else:
                header_h3.evaluate("el => el.click()")
        except Exception as e:
            log(f"       WARNING: click h3 attempt {attempt}: {e}")
            continue

        # Esperar a que quede activo
        time.sleep(0.4)
        wait_hidden(page, S["spinner"], 3000)
        try:
            header_class = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=1000) or ""
            if "ui-state-active" in header_class:
                return True
        except Exception:
            pass

    log(f"       ERROR: No se pudo abrir turno {cid}.")
    return False


def collect_carelog_ids(page: Page, year: int, month: int, day: int) -> list:
    """
    Recorre todos los h3[id^='carelog_'] del dia y extrae los CIDs + fechas.
    Abre cada uno momentaneamente para leer la fecha si el p.complete-datetime
    no es visible en estado colapsado.
    """
    h3s = page.locator("h3[id^='carelog_']")
    total = h3s.count()
    log(f"    Turnos en el dia: {total}")

    result = []
    for i in range(total):
        h3 = h3s.nth(i)
        try:
            cid = (h3.get_attribute("id") or "").replace("carelog_", "")
            if not cid:
                continue
        except Exception:
            continue

        # Solo turnos (Complete) — ignorar Cancelled, Missed, etc.
        try:
            h3_text = h3.inner_text(timeout=1000).lower()
            if "(complete)" not in h3_text:
                log(f"    SKIP turno no-complete (carelog_{cid}): '{h3_text.strip()}'")
                continue
        except Exception:
            pass

        # Intentar leer la fecha sin abrir (puede estar visible si quedo abierto)
        date_text = None
        try:
            p_el = page.locator(f"#carelog_{cid}_datetime")
            date_text = p_el.locator("a.edit-carelog").inner_text(timeout=1000)
        except Exception:
            pass

        # Si no se pudo leer, abrir el panel momentaneamente para leer
        if not date_text:
            if open_carelog_header(page, cid):
                try:
                    p_el = page.locator(f"#carelog_{cid}_datetime")
                    date_text = p_el.locator("a.edit-carelog").inner_text(timeout=2000)
                except Exception:
                    log(f"    WARNING: No se pudo leer fecha de carelog_{cid}.")
                    continue
            else:
                continue

        start_dt, end_dt = parse_carelog_range(date_text)
        if not start_dt or not end_dt:
            log(f"    WARNING: No se pudo parsear carelog_{cid}: '{date_text.strip()}'")
            continue

        if carelog_matches_rule(start_dt, year, month, day):
            log(f"    OK (carelog_{cid}): "
                f"{start_dt.strftime('%m/%d/%y %I:%M %p')} - {end_dt.strftime('%m/%d/%y %I:%M %p')}")
            result.append((cid, start_dt, end_dt))
        else:
            log(f"    SKIP (carelog_{cid}): "
                f"{start_dt.strftime('%m/%d/%y %I:%M %p')} - {end_dt.strftime('%m/%d/%y %I:%M %p')}")

    return result


def process_day(page: Page, year: int, month: int, day: int) -> int:
    log(f"[Day {day}] Procesando...")

    if not select_day(page, day):
        log(f"    WARNING: No se pudo seleccionar el dia {day}.")
        return 0

    time.sleep(1.5)

    if page.locator("h3[id^='carelog_']").count() == 0:
        log("    Sin care logs para este dia.")
        return 0

    carelogs_to_process = collect_carelog_ids(page, year, month, day)

    if not carelogs_to_process:
        log("    Sin care logs que empiecen entre 8am y 8pm.")
        return 0

    log(f"    Turnos a procesar: {len(carelogs_to_process)}")
    day_added = 0

    for cid, start_dt, end_dt in carelogs_to_process:
        # Abrir el turno (uno a la vez, acordeon exclusivo)
        if not open_carelog_header(page, cid):
            log(f"       ERROR: No se pudo abrir carelog_{cid}, se omite.")
            continue

        time.sleep(0.5)

        # Localizar panel de tareas
        panel = page.locator("div.tasks").filter(
            has=page.locator(f"#carelog_{cid}_datetime")
        )

        if panel.count() == 0:
            log(f"       WARNING: No se encontro panel de tareas para carelog_{cid}.")
            continue

        day_added += add_tasks_to_panel(panel.nth(0), page, end_dt)

    return day_added


# =========================
# MAIN
# =========================

def iter_dates(start_date: date, end_date: date):
    """Genera todos los (year, month, day) entre start_date y end_date inclusive."""
    current = start_date
    while current <= end_date:
        yield current.year, current.month, current.day
        current += timedelta(days=1)


def main():
    parser = argparse.ArgumentParser(
        description="Agregar tareas a Daily Care Logs en WellSky (turnos 8am-8pm)"
    )
    parser.add_argument("--client-url", required=True, help="URL del cliente en WellSky.")
    parser.add_argument("--headful", action="store_true", help="Mostrar navegador.")

    # Modo rango de fechas (recomendado para multiples meses)
    parser.add_argument("--start-date", help="Fecha inicial (YYYY-MM-DD). Ej: 2026-01-01")
    parser.add_argument("--end-date",   help="Fecha final   (YYYY-MM-DD). Ej: 2026-06-30")

    # Modo mes individual (compatibilidad con uso anterior)
    parser.add_argument("--year",      type=int, help="Año (ej: 2026).")
    parser.add_argument("--month",     type=int, help="Mes (1-12).")
    parser.add_argument("--start-day", type=int, help="Dia inicial.")
    parser.add_argument("--end-day",   type=int, help="Dia final.")

    args = parser.parse_args()

    # Resolver rango de fechas
    if args.start_date and args.end_date:
        try:
            start_date = datetime.strptime(args.start_date, "%Y-%m-%d").date()
            end_date   = datetime.strptime(args.end_date,   "%Y-%m-%d").date()
        except ValueError as e:
            log(f"ERROR: Formato de fecha invalido: {e}")
            return
    elif args.year and args.month and args.start_day and args.end_day:
        import calendar
        start_date = date(args.year, args.month, args.start_day)
        end_date   = date(args.year, args.month, args.end_day)
    else:
        parser.error("Debes usar --start-date/--end-date o --year/--month/--start-day/--end-day")
        return

    if end_date < start_date:
        log("ERROR: --end-date no puede ser menor que --start-date.")
        return

    log(f"Iniciando: Add daytime tasks (>= 8am < 8pm)...")
    log(f"Rango: {start_date.isoformat()} -> {end_date.isoformat()}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not args.headful)
        context = browser.new_context(
            storage_state="login_state.json",
            viewport={"width": 1400, "height": 950},
        )
        page = context.new_page()
        page.set_default_timeout(25000)

        page.goto(args.client_url, wait_until="domcontentloaded")
        wait_hidden(page, S["spinner"], 8000)

        # Ir a Daily Care Logs
        nav_ok = False
        for link_name in ("Daily Care Logs", "Daily Care Log"):
            try:
                page.get_by_role("link", name=link_name).click()
                nav_ok = True
                break
            except Exception:
                pass
        if not nav_ok:
            try:
                page.locator(S["daily_care_tab"]).first.click()
                nav_ok = True
            except Exception:
                pass
        if not nav_ok:
            log("ERROR: No se encontro el enlace 'Daily Care Logs'.")
            browser.close()
            return

        wait_hidden(page, S["spinner"], 8000)
        time.sleep(1.5)

        # Alinear calendario al mes del primer dia
        align_calendar(page, start_date.year, start_date.month)

        total_added = 0
        total_days  = 0
        current_month = (start_date.year, start_date.month)

        for year, month, day in iter_dates(start_date, end_date):
            # Realinar calendario si cambiamos de mes
            if (year, month) != current_month:
                log(f"--- Cambiando a {year}-{month:02d} ---")
                align_calendar(page, year, month)
                current_month = (year, month)
                time.sleep(0.5)

            try:
                added = process_day(page, year, month, day)
                total_added += added
                total_days  += 1
            except Exception as e:
                log(f"    ERROR procesando {year}-{month:02d}-{day:02d}: {e}")

        log("COMPLETADO.")
        log(f"Resumen -> dias procesados:{total_days} | tareas agregadas:{total_added}")

        try:
            context.storage_state(path="login_state.json")
        except Exception:
            pass
        browser.close()


if __name__ == "__main__":
    main()
