"""
Tasks_VA_delete.py
Elimina tareas especificas de turnos VA (Complete) en WellSky segun el tipo
de autorizacion (VA HHA o VA Respite), detectada leyendo el Bill Rate del modal.

Uso:
    python Tasks_VA_delete.py --client-url "https://..." --start-date 2026-01-01 --end-date 2026-06-30
    python Tasks_VA_delete.py --client-url "https://..." --year 2026 --month 1 --start-day 1 --end-day 31
"""
from __future__ import annotations

import argparse
import re
import time
from datetime import datetime, date, time as dt_time, timedelta
from typing import Optional, Tuple, List

from playwright.sync_api import sync_playwright, Page, Locator, TimeoutError as PWTimeout

# =========================
# CONFIG — EDITAR POR CLIENTE
# =========================

AUTH_RULES: dict[str, List[str]] = {
    "VA HHA": [
        "Bathe the client",
        "Brush hair",
        "Brush teeth",
        "Comb hair",
        "Dress the client",
        "Assist client with meal",
        "Feed the client",
        "Change bed linens",
    ],
    "VA Respite": [
        # Dejar vacio si no hay tareas que borrar para este tipo
    ],
}

# =========================
# SELECTORES
# =========================

MONTHS = {
    "January": 1, "February": 2, "March": 3, "April": 4,
    "May": 5, "June": 6, "July": 7, "August": 8,
    "September": 9, "October": 10, "November": 11, "December": 12,
}

S = {
    "spinner":        ".loading, .spinner, .ui-progressbar",
    "daily_care_tab": "a:has-text('Daily Care Log'), a:has-text('Daily Care Logs'), a[href*='carelog']",
    "cal_title":      ".ui-datepicker-title",
    "cal_prev":       "a.ui-datepicker-prev, span.ui-icon-circle-triangle-w",
    "cal_next":       "a.ui-datepicker-next, span.ui-icon-circle-triangle-e",
    "cal_day":        "table.ui-datepicker-calendar a.ui-state-default",
    "cal_active":     "table.ui-datepicker-calendar a.ui-state-active",
}

RATE_HHA_RE     = re.compile(r"VA.*HHA",     re.IGNORECASE)
RATE_RESPITE_RE = re.compile(r"VA.*Respite", re.IGNORECASE)

# =========================
# UTILS
# =========================

def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_hidden(page: Page, sel: str, t: int = 6000) -> None:
    try:
        page.locator(sel).first.wait_for(state="hidden", timeout=t)
    except Exception:
        pass


def close_modal(page: Page) -> None:
    for _ in range(3):
        try:
            page.keyboard.press("Escape")
            time.sleep(0.3)
        except Exception:
            pass
    try:
        page.locator(".ui-dialog-titlebar-close").first.click()
        time.sleep(0.3)
    except Exception:
        pass


# =========================
# CALENDARIO
# =========================

def read_cal_month_year(page: Page) -> Tuple[int, int]:
    try:
        title = page.locator(S["cal_title"]).first.inner_text(timeout=1500).strip()
        m = re.search(r"([A-Za-z]+)\s+(\d{4})", title)
        if not m:
            return 0, 0
        return MONTHS.get(m.group(1), 0), int(m.group(2))
    except Exception:
        return 0, 0


def align_calendar(page: Page, year: int, month: int) -> bool:
    for _ in range(30):
        cur_month, cur_year = read_cal_month_year(page)
        if cur_month == 0 or cur_year == 0:
            time.sleep(0.3)
            continue
        if cur_year == year and cur_month == month:
            return True
        try:
            if (cur_year, cur_month) > (year, month):
                page.locator(S["cal_prev"]).first.click()
            else:
                page.locator(S["cal_next"]).first.click()
        except Exception:
            pass
        time.sleep(0.3)
    log("WARNING: No se pudo alinear el calendario.")
    return False


def select_day(page: Page, day: int) -> bool:
    try:
        page.get_by_role("link", name=str(day), exact=True).click()
        time.sleep(0.5)
        return True
    except Exception:
        pass

    buttons = page.locator(S["cal_day"]).filter(has_text=str(day))
    if buttons.count() == 0:
        log(f"   WARNING: Dia {day} no encontrado en calendario.")
        return False

    for i in range(buttons.count()):
        b = buttons.nth(i)
        for attempt in range(3):
            try:
                if attempt == 0:
                    b.click()
                elif attempt == 1:
                    b.click(force=True)
                else:
                    b.evaluate("el => el.click()")
            except Exception:
                continue
            for _ in range(20):
                try:
                    active = page.locator(S["cal_active"]).first.inner_text(timeout=400).strip()
                    if active == str(day):
                        time.sleep(0.5)
                        wait_hidden(page, S["spinner"], 5000)
                        return True
                except Exception:
                    pass
                time.sleep(0.15)
    return False


# =========================
# PARSEO DE CARELOGS
# =========================

DT_RE = re.compile(
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))\s*-\s*"
    r"(\d{2}/\d{2}/\d{2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))"
)


def normalize_ampm(txt: str) -> str:
    return (
        txt.replace("a.m.", "AM").replace("p.m.", "PM")
           .replace("A.M.", "AM").replace("P.M.", "PM")
           .replace("a. m.", "AM").replace("p. m.", "PM")
    )


def parse_carelog_range(date_text: str) -> Tuple[Optional[datetime], Optional[datetime]]:
    txt = normalize_ampm(" ".join(date_text.split()))
    m = DT_RE.search(txt)
    if not m:
        return None, None
    start_date_s, start_time_s, end_date_s, end_time_s = m.groups()
    try:
        start_dt = datetime.strptime(f"{start_date_s} {start_time_s}", "%m/%d/%y %I:%M %p")
        end_dt   = datetime.strptime(f"{end_date_s} {end_time_s}",   "%m/%d/%y %I:%M %p")
        return start_dt, end_dt
    except ValueError:
        return None, None


# =========================
# LEER TIPO DE AUTH DEL MODAL
# =========================

def get_auth_type(page: Page, cid: str) -> Optional[str]:
    """
    Abre el modal del turno, lee el Bill Rate del change-list,
    y cierra el modal.
    Retorna 'VA HHA', 'VA Respite', o None si no es turno VA.
    """
    link = page.locator(f"#carelog_{cid}_datetime a.edit-carelog")
    try:
        link.wait_for(state="visible", timeout=5000)
        link.scroll_into_view_if_needed()
        time.sleep(0.3)
        link.click()
    except Exception as e:
        log(f"       WARNING: No se pudo abrir modal de carelog_{cid}: {e}")
        return None

    time.sleep(1.5)
    wait_hidden(page, S["spinner"], 5000)

    text = ""
    for _ in range(15):
        try:
            text = page.locator(".change-list").first.inner_text(timeout=1000)
            if "Bill Rate:" in text:
                break
        except Exception:
            pass
        time.sleep(0.3)

    snippet = text[text.find("Bill Rate:"):text.find("Bill Rate:")+40] if "Bill Rate:" in text else "NO BILL RATE"
    log(f"       change-list snippet: '{snippet}'")

    auth_type = None
    if RATE_HHA_RE.search(text):
        auth_type = "VA HHA"
    elif RATE_RESPITE_RE.search(text):
        auth_type = "VA Respite"
    else:
        log(f"       INFO: No se encontro VA HHA ni VA Respite en change-list.")

    close_modal(page)
    time.sleep(0.5)
    wait_hidden(page, S["spinner"], 4000)
    return auth_type


# =========================
# ABRIR HEADER DEL TURNO
# =========================

def open_carelog_header(page: Page, cid: str) -> bool:
    try:
        cls = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=2000) or ""
        if "ui-state-active" in cls:
            log(f"       Turno {cid} ya esta abierto.")
            return True
    except Exception:
        pass

    h3 = page.locator(f"h3#carelog_{cid}")
    for attempt in range(4):
        try:
            if attempt == 0:
                h3.click()
            elif attempt == 1:
                h3.click(force=True)
            elif attempt == 2:
                h3.dispatch_event("click")
            else:
                h3.evaluate("el => el.click()")
        except Exception as e:
            log(f"       WARNING: click h3 attempt {attempt}: {e}")
            continue

        time.sleep(0.4)
        wait_hidden(page, S["spinner"], 3000)
        try:
            cls = page.locator(f"h3#carelog_{cid}").get_attribute("class", timeout=1000) or ""
            if "ui-state-active" in cls:
                return True
        except Exception:
            pass

    log(f"       ERROR: No se pudo abrir turno {cid}.")
    return False


# =========================
# BORRAR TAREAS DEL PANEL
# =========================

import math

def _center_point_of(locator: Locator) -> Optional[dict]:
    try:
        box = locator.bounding_box()
        if not box:
            return None
        return {"x": box["x"] + box["width"] / 2, "y": box["y"] + box["height"] / 2}
    except Exception:
        return None


def is_element_visibly_clickable(page: Page, locator: Locator):
    try:
        handle = locator.element_handle()
        if not handle:
            return False, "Sin element_handle"
        style_and_attrs = page.evaluate("""
        (el) => {
          const cs = getComputedStyle(el);
          return {
            visible: cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0',
            pointer: cs.pointerEvents !== 'none',
            disabled: !!(el.disabled || el.getAttribute('disabled') !== null
                         || el.getAttribute('aria-disabled') === 'true'),
            rect: el.getBoundingClientRect().toJSON(),
          };
        }
        """, handle)
        if not style_and_attrs["visible"]:
            return False, "No visible"
        if not style_and_attrs["pointer"]:
            return False, "pointer-events:none"
        if style_and_attrs["disabled"]:
            return False, "Disabled"
        r = style_and_attrs["rect"]
        viewport = page.viewport_size or {"width": 1400, "height": 950}
        if (r["right"] <= 0 or r["bottom"] <= 0
                or r["left"] >= viewport["width"] or r["top"] >= viewport["height"]):
            return False, "Fuera de viewport"
        center_x = max(0, min(viewport["width"] - 1, r["left"] + r["width"] / 2))
        center_y = max(0, min(viewport["height"] - 1, r["top"] + r["height"] / 2))
        top_info = page.evaluate("""
        ({x, y, el}) => {
          const top = document.elementFromPoint(x, y);
          if (!top) return { covers: true, path: [] };
          const path = [];
          let cur = top;
          for (let i = 0; i < 6 && cur; i++) {
            path.push(cur.tagName + (cur.id ? "#" + cur.id : ""));
            cur = cur.parentElement;
          }
          return { covers: top !== el && !el.contains(top), path };
        }
        """, {"x": center_x, "y": center_y, "el": handle})
        if top_info and top_info.get("covers"):
            return False, f"Overlay: {' > '.join(top_info.get('path', []))}"
        return True, ""
    except Exception as e:
        return False, f"Excepcion: {e}"


def click_top_yes_dialog(page: Page, timeout_ms: int = 8000) -> bool:
    import math as _math
    t0 = time.time()
    last_reason = "desconocido"
    while (time.time() - t0) * 1000 < timeout_ms:
        try:
            dialogs = page.locator(".ui-dialog")
            n = dialogs.count()
            if n == 0:
                time.sleep(0.05)
                continue
            top_idx, top_z = -1, -_math.inf
            for i in range(n):
                dlg = dialogs.nth(i)
                try:
                    if not dlg.is_visible():
                        continue
                    z = dlg.evaluate("el => parseInt(getComputedStyle(el).zIndex) || 0")
                    if z > top_z:
                        top_z, top_idx = z, i
                except Exception:
                    continue
            if top_idx < 0:
                time.sleep(0.05)
                continue
            dlg = dialogs.nth(top_idx)
            try:
                dlg.scroll_into_view_if_needed(timeout=400)
            except Exception:
                pass
            yes = dlg.locator("button:has(span.ui-button-text:has-text('Yes'))").first
            try:
                yes.wait_for(state="visible", timeout=900)
            except Exception:
                last_reason = "Yes no visible"
                time.sleep(0.05)
                continue
            for j in range(7):
                try:
                    if j == 0:
                        yes.click()
                    elif j == 1:
                        yes.click(force=True)
                    elif j == 2:
                        yes.dispatch_event("click")
                    elif j == 3:
                        yes.evaluate("el => el.click()")
                    elif j == 4:
                        yes.focus()
                        page.keyboard.press("Enter")
                    elif j == 5:
                        pt = _center_point_of(yes)
                        if pt:
                            page.mouse.move(pt["x"], pt["y"])
                            page.mouse.click(pt["x"], pt["y"])
                    else:
                        pt = _center_point_of(yes)
                        if pt:
                            page.mouse.click(pt["x"] + 3, pt["y"] + 3)
                    for state in ("detached", "hidden"):
                        try:
                            dlg.wait_for(state=state, timeout=1500)
                            return True
                        except Exception:
                            pass
                except Exception as e:
                    last_reason = f"click j={j}: {e}"
            time.sleep(0.06)
        except Exception as e:
            last_reason = f"ciclo: {e}"
            time.sleep(0.06)
    log(f"       WARNING: No se pudo confirmar Yes. Razon: {last_reason}")
    try:
        page.keyboard.press("Escape")
    except Exception:
        pass
    return False


def confirm_yes(page: Page) -> bool:
    return click_top_yes_dialog(page, timeout_ms=8000)


def click_delete_x(page: Page, row: Locator) -> bool:
    """Hover + clic en la X de eliminacion con fallbacks."""
    try:
        row.hover()
        time.sleep(0.08)
    except Exception:
        pass

    btn = row.locator("a.show_on_hover").first
    if btn.count() == 0:
        log("       WARNING: No se encontro la X (show_on_hover).")
        return False

    try:
        btn.wait_for(state="visible", timeout=1000)
    except Exception:
        log("       WARNING: La X nunca se hizo visible.")
        return False

    for attempt in range(4):
        try:
            if attempt == 0:
                btn.click(timeout=1000)
            elif attempt == 1:
                btn.click(force=True, timeout=1000)
            elif attempt == 2:
                btn.dispatch_event("click")
            else:
                btn.evaluate("el => el.click()")
            return True
        except Exception:
            pass

    log("       WARNING: No se pudo hacer click en la X.")
    return False


def delete_tasks_from_panel(panel: Locator, page: Page, tasks_to_delete: List[str]) -> int:
    """
    Busca y elimina las tareas especificadas en el panel del carelog.
    Usa la misma logica robusta del script Tasks_delete_by_name_full_yearCL.
    """
    deleted = 0

    for task_title in tasks_to_delete:
        # Re-query en cada iteracion porque el DOM cambia al borrar
        tasks = panel.locator("div.task_title")
        count = tasks.count()

        target_row = None
        for i in range(count):
            row = tasks.nth(i)
            try:
                name = row.locator("a.link_no_color").first.inner_text(timeout=500).strip()
                if name.lower() == task_title.lower():
                    target_row = row
                    break
            except Exception:
                continue

        if target_row is None:
            log(f"       SKIP: '{task_title}' no encontrada.")
            continue

        log(f"       BORRAR: '{task_title}'")

        if not click_delete_x(page, target_row):
            continue

        time.sleep(0.15)

        if confirm_yes(page):
            time.sleep(0.25)
            wait_hidden(page, S["spinner"], 4000)
            deleted += 1
            log(f"       OK: '{task_title}' eliminada.")
        else:
            log(f"       WARNING: No se pudo confirmar borrado de '{task_title}'.")

    return deleted

def collect_carelog_ids(page: Page, year: int, month: int, day: int) -> list:
    h3s = page.locator("h3[id^='carelog_']")
    total = h3s.count()
    log(f"    Turnos en el dia: {total}")

    result = []
    for i in range(total):
        h3 = h3s.nth(i)
        try:
            cid = (h3.get_attribute("id") or "").replace("carelog_", "")
            if not cid:
                continue
        except Exception:
            continue

        # Solo (Complete)
        try:
            h3_text = h3.inner_text(timeout=1000).lower()
            if "(complete)" not in h3_text:
                log(f"    SKIP no-complete (carelog_{cid})")
                continue
        except Exception:
            pass

        # Leer fecha
        date_text = None
        try:
            date_text = page.locator(f"#carelog_{cid}_datetime a.edit-carelog").inner_text(timeout=1000)
        except Exception:
            pass

        if not date_text:
            if open_carelog_header(page, cid):
                try:
                    date_text = page.locator(f"#carelog_{cid}_datetime a.edit-carelog").inner_text(timeout=2000)
                except Exception:
                    log(f"    WARNING: No se pudo leer fecha de carelog_{cid}.")
                    continue
            else:
                continue

        start_dt, end_dt = parse_carelog_range(date_text)
        if not start_dt or not end_dt:
            log(f"    WARNING: No se pudo parsear carelog_{cid}.")
            continue

        if start_dt.date() == date(year, month, day):
            log(f"    OK (carelog_{cid}): "
                f"{start_dt.strftime('%m/%d/%y %I:%M %p')} - {end_dt.strftime('%m/%d/%y %I:%M %p')}")
            result.append((cid, start_dt, end_dt))
        else:
            log(f"    SKIP fecha no coincide (carelog_{cid})")

    return result


# =========================
# PROCESO DIA
# =========================

def process_day(page: Page, year: int, month: int, day: int) -> int:
    log(f"[Day {year}-{month:02d}-{day:02d}] Procesando...")

    if not select_day(page, day):
        log(f"    WARNING: No se pudo seleccionar el dia {day}.")
        return 0

    time.sleep(1.5)

    if page.locator("h3[id^='carelog_']").count() == 0:
        log("    Sin care logs para este dia.")
        return 0

    carelogs = collect_carelog_ids(page, year, month, day)

    if not carelogs:
        log("    Sin turnos Complete para este dia.")
        return 0

    day_deleted = 0

    for cid, start_dt, end_dt in carelogs:
        log(f"    Procesando carelog_{cid}...")

        if not open_carelog_header(page, cid):
            log(f"       ERROR: No se pudo abrir carelog_{cid}, se omite.")
            continue

        time.sleep(0.5)

        # Leer tipo de auth desde el modal
        auth_type = get_auth_type(page, cid)

        if not auth_type:
            log(f"       SKIP carelog_{cid}: no es turno VA o no se pudo determinar auth.")
            continue

        log(f"       Auth detectada: {auth_type}")

        tasks_to_delete = AUTH_RULES.get(auth_type, [])
        if not tasks_to_delete:
            log(f"       INFO: No hay tareas configuradas para borrar en '{auth_type}'.")
            continue

        # Re-abrir el acordeon tras cerrar el modal
        if not open_carelog_header(page, cid):
            log(f"       ERROR: No se pudo re-abrir carelog_{cid} tras cerrar modal.")
            continue

        time.sleep(0.5)

        panel = page.locator("div.tasks").filter(
            has=page.locator(f"#carelog_{cid}_datetime")
        )

        if panel.count() == 0:
            log(f"       WARNING: No se encontro panel de tareas para carelog_{cid}.")
            continue

        day_deleted += delete_tasks_from_panel(panel.nth(0), page, tasks_to_delete)

    return day_deleted


# =========================
# ITERAR FECHAS
# =========================

def iter_dates(start_date: date, end_date: date):
    current = start_date
    while current <= end_date:
        yield current.year, current.month, current.day
        current += timedelta(days=1)


# =========================
# MAIN
# =========================

def main():
    parser = argparse.ArgumentParser(
        description="Eliminar tareas de turnos VA (HHA/Respite) en WellSky segun autorizacion."
    )
    parser.add_argument("--client-url", required=True, help="URL del cliente en WellSky.")
    parser.add_argument("--headful", action="store_true", help="Mostrar navegador.")

    parser.add_argument("--start-date", help="Fecha inicial (YYYY-MM-DD).")
    parser.add_argument("--end-date",   help="Fecha final   (YYYY-MM-DD).")

    parser.add_argument("--year",      type=int)
    parser.add_argument("--month",     type=int)
    parser.add_argument("--start-day", type=int)
    parser.add_argument("--end-day",   type=int)

    args = parser.parse_args()

    if args.start_date and args.end_date:
        try:
            start_date = datetime.strptime(args.start_date, "%Y-%m-%d").date()
            end_date   = datetime.strptime(args.end_date,   "%Y-%m-%d").date()
        except ValueError as e:
            log(f"ERROR: Formato de fecha invalido: {e}")
            return
    elif args.year and args.month and args.start_day and args.end_day:
        start_date = date(args.year, args.month, args.start_day)
        end_date   = date(args.year, args.month, args.end_day)
    else:
        parser.error("Usa --start-date/--end-date o --year/--month/--start-day/--end-day")
        return

    if end_date < start_date:
        log("ERROR: --end-date no puede ser menor que --start-date.")
        return

    log("Iniciando: Tasks_VA_delete...")
    log(f"Rango: {start_date.isoformat()} -> {end_date.isoformat()}")
    log(f"Auth rules configuradas: {list(AUTH_RULES.keys())}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not args.headful)
        context = browser.new_context(
            storage_state="login_state.json",
            viewport={"width": 1400, "height": 950},
        )
        page = context.new_page()
        page.set_default_timeout(25000)

        page.goto(args.client_url, wait_until="domcontentloaded")
        wait_hidden(page, S["spinner"], 8000)

        nav_ok = False
        for link_name in ("Daily Care Logs", "Daily Care Log"):
            try:
                page.get_by_role("link", name=link_name).click()
                nav_ok = True
                break
            except Exception:
                pass
        if not nav_ok:
            try:
                page.locator(S["daily_care_tab"]).first.click()
                nav_ok = True
            except Exception:
                pass
        if not nav_ok:
            log("ERROR: No se encontro el enlace 'Daily Care Logs'.")
            browser.close()
            return

        wait_hidden(page, S["spinner"], 8000)
        time.sleep(1.5)

        align_calendar(page, start_date.year, start_date.month)

        total_deleted = 0
        total_days    = 0
        current_month = (start_date.year, start_date.month)

        for year, month, day in iter_dates(start_date, end_date):
            if (year, month) != current_month:
                log(f"--- Cambiando a {year}-{month:02d} ---")
                align_calendar(page, year, month)
                current_month = (year, month)
                time.sleep(0.5)

            try:
                deleted = process_day(page, year, month, day)
                total_deleted += deleted
                total_days    += 1
            except Exception as e:
                log(f"    ERROR procesando {year}-{month:02d}-{day:02d}: {e}")

        log("COMPLETADO.")
        log(f"Resumen -> dias procesados:{total_days} | tareas eliminadas:{total_deleted}")

        try:
            context.storage_state(path="login_state.json")
        except Exception:
            pass
        browser.close()


if __name__ == "__main__":
    main()
