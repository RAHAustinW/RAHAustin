"""
Tasks_delete_by_name_full_year.py  — v2.0 (robust)
Borra tareas específicas en turnos COMPLETOS en un rango de fechas (WellSky/ClearCare).

Fixes vs v1:
- page.evaluate() con múltiples args → empacados en dict (error principal del usuario)
- is_element_visibly_clickable: topInfo evaluate corregido
- navigate_to_month: usa selectores más amplios (prev/next)
- confirm_yes: fallbacks adicionales
- close_stale_dialogs: no borra el DOM, solo presiona Escape
- Logging mejorado con conteo final
"""
from __future__ import annotations

import argparse
import math
import time
from datetime import datetime, date, timedelta
from typing import Optional, Tuple

from playwright.sync_api import sync_playwright, Page, Locator

# =========================
# CONFIG
# =========================

TARGET_TASKS = [
    "assist into and out of shower",
    "walk with client",
    "assist client with commode",
    "change bed linens",
    "monitor in bath",
    "assist with dressing",
    "monitor dressing",
    "dress the client",
    "assist client with meal",
    "clean kitchen",
    "do laundry"
]

S = {
    "any_dialog": ".ui-dialog",
    "spinner": ".loading, .spinner, .ui-progressbar",
    "daily_care_tab": "a:has-text('Daily Care Log'), a:has-text('Daily Care Logs'), a[href*='carelog']",
    "calendar_month": ".ui-datepicker-title .ui-datepicker-month",
    "calendar_year": ".ui-datepicker-title .ui-datepicker-year",
    "cal_prev": "a.ui-datepicker-prev, span.ui-icon-circle-triangle-w",
    "cal_next": "a.ui-datepicker-next, span.ui-icon-circle-triangle-e",
    "cal_day": "table.ui-datepicker-calendar a.ui-state-default",
    "cal_active": "table.ui-datepicker-calendar a.ui-state-active",
}

MONTHS = {
    "January": 1, "February": 2, "March": 3, "April": 4,
    "May": 5, "June": 6, "July": 7, "August": 8,
    "September": 9, "October": 10, "November": 11, "December": 12,
}


# =========================
# UTILS
# =========================

def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_hidden(page: Page, sel: str, t: int = 6000) -> None:
    try:
        page.locator(sel).first.wait_for(state="hidden", timeout=t)
    except Exception:
        pass


# =========================
# NAVEGACION AL CLIENTE
# =========================

def ensure_on_client(page: Page, client_url: str) -> None:
    if not client_url.endswith("/"):
        client_url += "/"
    if not page.url.startswith(client_url):
        page.goto(client_url, timeout=60000, wait_until="domcontentloaded")
        time.sleep(1.5)
    wait_hidden(page, S["spinner"], 8000)
    try:
        tab = page.locator(S["daily_care_tab"])
        if tab.count() > 0:
            tab.first.click()
            time.sleep(1.0)
            wait_hidden(page, S["spinner"], 8000)
    except Exception:
        pass


# =========================
# CALENDARIO
# =========================

def read_month_year(page: Page) -> Tuple[int, int]:
    try:
        mtxt = page.locator(S["calendar_month"]).first.inner_text(timeout=1500).strip()
        ytxt = page.locator(S["calendar_year"]).first.inner_text(timeout=1500).strip()
        return MONTHS.get(mtxt, 0), int(ytxt)
    except Exception:
        return 0, 0


def navigate_to_month(page: Page, target_year: int, target_month: int) -> bool:
    target_index = target_year * 12 + target_month
    for _ in range(120):
        cur_month, cur_year = read_month_year(page)
        if cur_month == 0 or cur_year == 0:
            time.sleep(0.3)
            continue
        if cur_year == target_year and cur_month == target_month:
            return True
        cur_index = cur_year * 12 + cur_month
        try:
            if cur_index < target_index:
                page.locator(S["cal_next"]).first.click()
            else:
                page.locator(S["cal_prev"]).first.click()
        except Exception:
            pass
        time.sleep(0.25)
    log("WARNING: No se pudo llegar al mes/año objetivo.")
    return False


def click_day(page: Page, day: int) -> bool:
    buttons = page.locator(S["cal_day"]).filter(has_text=str(day))
    if buttons.count() == 0:
        log(f"   WARNING: No se encontro el dia {day} en el calendario.")
        return False

    for i in range(buttons.count()):
        b = buttons.nth(i)
        for attempt in range(3):
            try:
                if attempt == 0:
                    b.click()
                elif attempt == 1:
                    b.click(force=True)
                else:
                    b.evaluate("el => el.click()")
            except Exception:
                continue

            for _ in range(25):
                try:
                    active_text = page.locator(S["cal_active"]).first.inner_text(timeout=400).strip()
                except Exception:
                    active_text = ""
                if active_text == str(day):
                    time.sleep(0.5)
                    wait_hidden(page, S["spinner"], 5000)
                    return True
                time.sleep(0.15)

    log(f"   WARNING: No se pudo activar el dia {day}.")
    return False


def go_to_date(page: Page, d: date) -> bool:
    if not navigate_to_month(page, d.year, d.month):
        return False
    return click_day(page, d.day)


# =========================
# DIAGNOSTICO Y CLICK SEGURO
# =========================

def _center_point_of(locator: Locator) -> Optional[dict]:
    try:
        box = locator.bounding_box()
        if not box:
            return None
        return {"x": box["x"] + box["width"] / 2, "y": box["y"] + box["height"] / 2}
    except Exception:
        return None


def is_element_visibly_clickable(page: Page, locator: Locator) -> Tuple[bool, str]:
    """
    FIX: page.evaluate() con multiples args empacados en un unico dict.
    Diagnostica si un elemento es visiblemente clickeable.
    """
    try:
        handle = locator.element_handle()
        if not handle:
            return False, "Sin element_handle"

        style_and_attrs = page.evaluate("""
        (el) => {
          const cs = getComputedStyle(el);
          return {
            visible: cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0',
            pointer: cs.pointerEvents !== 'none',
            disabled: !!(el.disabled || el.getAttribute('disabled') !== null
                         || el.getAttribute('aria-disabled') === 'true'),
            rect: el.getBoundingClientRect().toJSON(),
          };
        }
        """, handle)

        if not style_and_attrs["visible"]:
            return False, "No visible (display/visibility/opacity)"
        if not style_and_attrs["pointer"]:
            return False, "pointer-events:none"
        if style_and_attrs["disabled"]:
            return False, "Disabled/aria-disabled"

        r = style_and_attrs["rect"]
        viewport = page.viewport_size or {"width": 1400, "height": 950}
        if (r["right"] <= 0 or r["bottom"] <= 0
                or r["left"] >= viewport["width"] or r["top"] >= viewport["height"]):
            return False, "Fuera de viewport"

        center_x = max(0, min(viewport["width"] - 1, r["left"] + r["width"] / 2))
        center_y = max(0, min(viewport["height"] - 1, r["top"] + r["height"] / 2))

        # FIX PRINCIPAL: empacar x, y, el en un solo dict
        top_info = page.evaluate("""
        ({x, y, el}) => {
          const top = document.elementFromPoint(x, y);
          if (!top) return { covers: true, path: [] };
          const path = [];
          let cur = top;
          for (let i = 0; i < 6 && cur; i++) {
            path.push(cur.tagName + (cur.id ? '#' + cur.id : ''));
            cur = cur.parentElement;
          }
          return { covers: top !== el && !el.contains(top), path };
        }
        """, {"x": center_x, "y": center_y, "el": handle})

        if top_info and top_info.get("covers"):
            return False, f"Overlay encima: {' > '.join(top_info.get('path', []))}"

        return True, ""
    except Exception as e:
        return False, f"Excepcion diagnostico: {e}"


def click_top_yes_dialog(page: Page, timeout_ms: int = 8000) -> bool:
    """Encuentra el dialogo mas arriba y confirma 'Yes' con multiples fallbacks."""
    t0 = time.time()
    last_reason = "desconocido"

    while (time.time() - t0) * 1000 < timeout_ms:
        try:
            dialogs = page.locator(S["any_dialog"])
            n = dialogs.count()
            if n == 0:
                time.sleep(0.05)
                continue

            top_idx, top_z = -1, -math.inf
            for i in range(n):
                dlg = dialogs.nth(i)
                try:
                    if not dlg.is_visible():
                        continue
                    z = dlg.evaluate("el => parseInt(getComputedStyle(el).zIndex) || 0")
                    if z > top_z:
                        top_z, top_idx = z, i
                except Exception:
                    continue

            if top_idx < 0:
                time.sleep(0.05)
                continue

            dlg = dialogs.nth(top_idx)
            try:
                dlg.scroll_into_view_if_needed(timeout=400)
            except Exception:
                pass

            yes = dlg.locator("button:has(span.ui-button-text:has-text('Yes'))").first
            try:
                yes.wait_for(state="visible", timeout=900)
            except Exception:
                last_reason = "Yes no visible aun"
                time.sleep(0.05)
                continue

            ok_clickable, reason = is_element_visibly_clickable(page, yes)
            if not ok_clickable:
                last_reason = reason or "No clickable"
                log(f"   [diag] 'Yes' button: {last_reason}")
                try:
                    yes.scroll_into_view_if_needed(timeout=300)
                except Exception:
                    pass

            for j in range(7):
                try:
                    if j == 0:
                        yes.click()
                    elif j == 1:
                        yes.click(force=True)
                    elif j == 2:
                        yes.dispatch_event("click")
                    elif j == 3:
                        yes.evaluate("el => el.click()")
                    elif j == 4:
                        yes.focus()
                        page.keyboard.press("Enter")
                    elif j == 5:
                        pt = _center_point_of(yes)
                        if pt:
                            page.mouse.move(pt["x"], pt["y"])
                            page.mouse.click(pt["x"], pt["y"])
                    else:
                        pt = _center_point_of(yes)
                        if pt:
                            page.mouse.click(pt["x"] + 3, pt["y"] + 3)

                    for state in ("detached", "hidden"):
                        try:
                            dlg.wait_for(state=state, timeout=1500)
                            log(f"   OK Dialog confirmado con 'Yes' ({state}).")
                            return True
                        except Exception:
                            pass
                except Exception as e:
                    last_reason = f"Excepcion click j={j}: {e}"

            time.sleep(0.06)
        except Exception as e:
            last_reason = f"Excepcion ciclo: {e}"
            time.sleep(0.06)

    log(f"   WARNING: No se pudo confirmar 'Yes' en {timeout_ms}ms. Razon: {last_reason}")
    try:
        page.keyboard.press("Escape")
    except Exception:
        pass
    return False


def confirm_yes(page: Page) -> bool:
    return click_top_yes_dialog(page, timeout_ms=8000)


def close_stale_dialogs(page: Page) -> None:
    """Cierra dialogos residuales con Escape (no elimina el DOM)."""
    try:
        if page.locator(S["any_dialog"]).count() > 0:
            page.keyboard.press("Escape")
            time.sleep(0.2)
    except Exception:
        pass


# =========================
# TURNOS Y TAREAS
# =========================

def get_completed_headers(page: Page) -> list:
    anchors = page.locator(".ui-accordion-header a")
    headers = []
    for i in range(anchors.count()):
        try:
            txt = (anchors.nth(i).inner_text(timeout=500) or "").strip().lower()
            if "(complete)" in txt:
                headers.append(anchors.nth(i))
        except Exception:
            continue
    return headers


def activate_header(page: Page, header: Locator) -> bool:
    try:
        header.scroll_into_view_if_needed(timeout=800)
    except Exception:
        pass

    panel = None
    try:
        panel = header.locator("xpath=ancestor::h3[1]/following-sibling::div[1]")
        panel_class = panel.get_attribute("class") or ""
        if "ui-accordion-content-active" in panel_class and panel.locator("div.task_title").count() > 0:
            return True
    except Exception:
        pass

    for j in range(7):
        try:
            if j == 0:
                header.click()
            elif j == 1:
                header.click(force=True)
            elif j == 2:
                header.dispatch_event("click")
            elif j == 3:
                page.evaluate("(el) => el.click()", header)
            elif j == 4:
                header.dblclick()
            elif j == 5:
                header.focus()
                page.keyboard.press("Enter")
            else:
                box = header.bounding_box()
                if box:
                    page.mouse.click(box["x"] + 10, box["y"] + 10)
        except Exception:
            pass

        time.sleep(0.3)

        try:
            if panel is not None:
                panel_class = panel.get_attribute("class") or ""
                if "ui-accordion-content-active" in panel_class and panel.locator("div.task_title").count() > 0:
                    return True
        except Exception:
            pass

    log("   WARNING: No se pudo expandir un turno '(Complete)'.")
    return False


def get_task_name(row: Locator) -> str:
    try:
        return row.locator("a.link_no_color").first.inner_text(timeout=500).strip()
    except Exception:
        return ""


def matches_target(name: str) -> bool:
    name_low = (name or "").lower()
    return any(pat in name_low for pat in TARGET_TASKS)


def click_delete_x(page: Page, row: Locator) -> bool:
    """Hover + clic en la X de eliminacion con fallbacks."""
    try:
        row.hover()
        time.sleep(0.08)
    except Exception:
        pass

    btn = row.locator("a.show_on_hover").first
    if btn.count() == 0:
        log("   WARNING: No se encontro la X (show_on_hover).")
        return False

    try:
        btn.wait_for(state="visible", timeout=1000)
    except Exception:
        log("   WARNING: La X nunca se hizo visible, se salta.")
        return False

    last_err = None
    for attempt in range(4):
        try:
            if attempt == 0:
                btn.click(timeout=1000)
            elif attempt == 1:
                btn.click(force=True, timeout=1000)
            elif attempt == 2:
                btn.dispatch_event("click")
            else:
                btn.evaluate("el => el.click()")
            return True
        except Exception as e:
            last_err = e

    log(f"   WARNING: No se pudo hacer click en la X. Error: {last_err}")
    return False


def delete_matching_tasks_in_completed_shifts(page: Page) -> int:
    """
    Recorre cada turno (Complete) y elimina las tareas que coincidan con TARGET_TASKS.
    Retorna total de tareas eliminadas.
    """
    total_deleted = 0
    close_stale_dialogs(page)

    headers = get_completed_headers(page)
    log(f"   Turnos completos encontrados: {len(headers)}")
    if not headers:
        return 0

    for idx in range(len(headers)):
        header = headers[idx]
        log(f"   Procesando turno #{idx + 1}")

        if not activate_header(page, header):
            log("      WARNING: No se pudo abrir este turno, se omite.")
            continue

        try:
            panel = header.locator("xpath=ancestor::h3[1]/following-sibling::div[1]")
        except Exception:
            log("      WARNING: No se encontro el panel, se omite.")
            continue

        tasks = panel.locator("div.task_title")
        log(f"      Tareas en este turno: {tasks.count()}")

        j = 0
        safe = 0
        while j < tasks.count() and safe < 200:
            safe += 1
            row = tasks.nth(j)
            name = get_task_name(row)

            if matches_target(name):
                log(f"         BORRAR: '{name}'")
                if click_delete_x(page, row):
                    time.sleep(0.15)
                    if confirm_yes(page):
                        time.sleep(0.25)
                        wait_hidden(page, S["spinner"], 4000)
                        total_deleted += 1
                        tasks = panel.locator("div.task_title")
                        continue
                    else:
                        log("         WARNING: No se pudo confirmar 'Yes', saltando.")
            j += 1

    return total_deleted


# =========================
# BUCLE PRINCIPAL
# =========================

def parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def run(client_url: str, start_date: date, end_date: date, headful: bool) -> None:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not headful)
        context = browser.new_context(
            storage_state="login_state.json",
            viewport={"width": 1400, "height": 900},
        )
        page = context.new_page()
        page.set_default_timeout(30000)

        ensure_on_client(page, client_url)

        current = start_date
        total_all = 0
        days_processed = 0

        while current <= end_date:
            log(f"Procesando: {current.isoformat()}")
            try:
                if not go_to_date(page, current):
                    log("   WARNING: No se pudo posicionar en esta fecha.")
                    current += timedelta(days=1)
                    continue

                time.sleep(0.7)
                deleted_today = delete_matching_tasks_in_completed_shifts(page)
                log(f"   Tareas borradas hoy: {deleted_today}")
                total_all += deleted_today
                days_processed += 1
            except Exception as e:
                log(f"   ERROR inesperado en {current.isoformat()}: {e}")

            current += timedelta(days=1)

        log(f"COMPLETADO. Dias procesados: {days_processed} | TOTAL TAREAS BORRADAS: {total_all}")
        try:
            context.storage_state(path="login_state.json")
        except Exception:
            pass
        browser.close()


def main():
    ap = argparse.ArgumentParser(
        description="Borrar tareas especificas en turnos COMPLETOS - v2.0 robust"
    )
    ap.add_argument("--client-url", required=True, help="URL del cliente en WellSky/ClearCare")
    ap.add_argument("--start-date", required=True, help="Fecha inicial (YYYY-MM-DD)")
    ap.add_argument("--end-date", required=True, help="Fecha final (YYYY-MM-DD)")
    ap.add_argument("--headful", action="store_true", help="Mostrar el navegador")
    args = ap.parse_args()

    start = parse_date(args.start_date)
    end = parse_date(args.end_date)
    if end < start:
        raise SystemExit("--end-date no puede ser menor que --start-date")

    run(args.client_url, start, end, headful=args.headful)


if __name__ == "__main__":
    main()
