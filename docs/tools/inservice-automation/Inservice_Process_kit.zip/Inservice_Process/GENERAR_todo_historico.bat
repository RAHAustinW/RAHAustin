@echo off
cd /d "%~dp0"
echo Generando TODO: Initial + Inservice de TODOS los anos de antiguedad ...
python inservice_generator.py --initial --year --scope all
echo.
echo Revisa output_inservice\  y luego usa SUBIR_todo.bat
pause
