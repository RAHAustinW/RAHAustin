@echo off
cd /d "%~dp0"
echo Archivando el lote ya subido (PDFs y Excel) ...
python archivar.py
pause
