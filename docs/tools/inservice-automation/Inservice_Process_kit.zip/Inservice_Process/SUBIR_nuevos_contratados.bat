@echo off
cd /d "%~dp0"
echo === VISTA PREVIA (no sube nada) ===
python inservice_upload_wellsky.py --initial --no-year --dry-run
echo.
set /p ok="Se ve bien? Escribe S y Enter para SUBIR de verdad: "
if /i "%ok%"=="S" (python inservice_upload_wellsky.py --initial --no-year) else (echo Cancelado.)
pause
