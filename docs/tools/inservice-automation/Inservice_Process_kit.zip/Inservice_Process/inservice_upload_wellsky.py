# -*- coding: utf-8 -*-
"""
Inservice WellSky Upload — Right at Home Central Texas
======================================================
Sube a WellSky los PDFs generados por inservice_generator.py.

Reusa el núcleo probado de bgc_04_upload_wellsky.py (búsqueda de perfil,
extracción de edit_profile_id y POST a /profile/upload-file/{id}/).
La diferencia: aquí los archivos están en DOS carpetas planas y el nombre del
CG va en el archivo, así que se agrupan por caregiver leyendo el Excel de input/.

Flujo:
  1. Lee el Excel de input/ (mismas exclusiones que el generador).
  2. Para cada CG arma su nombre de búsqueda (First Last) y junta sus PDFs
     desde output_inservice/Initial_Training y/o Inservice_Year (según toggles).
  3. Busca el perfil en WellSky, obtiene el edit_profile_id y sube cada PDF.

Uso:
  python inservice_upload_wellsky.py                 # sube según los toggles
  python inservice_upload_wellsky.py --dry-run       # muestra qué subiría, NO sube
  python inservice_upload_wellsky.py --cg Aiken_Sherrie

Prerequisitos:
  - Haber corrido inservice_generator.py (carpeta output_inservice/ poblada)
  - login_state.json válido (correr capture_login_state.py si no existe)
  - pip install playwright pandas xlrd openpyxl ; playwright install chromium

Autor: Angel Pabuence — Right at Home Central Texas
"""

import os
import re
import sys
import time
import getpass
import argparse
from pathlib import Path

import pandas as pd

# ─────────────────────────────────────────────────────────────
#  CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────
WELLSKY_URL = "https://rahaustinwest.clearcareonline.com/"   # mismo tenant para todas las oficinas

INPUT_DIR   = "input"               # Excel de WellSky (para nombres + exclusiones)
OUTPUT_DIR  = "output_inservice"    # carpeta con los PDFs generados

# QUÉ SUBIR — igual que en el generador
UPLOAD_INITIAL = True               # Initial_Training/
UPLOAD_YEAR    = True               # Inservice_Year/

# Mismas exclusiones que el generador
EXTRA_EXCLUDE = [
    ("Victoria", None),             # RN — set her last name here when known
]

HEADLESS       = False              # True para correr sin ventana visible
PAUSA_ENTRE_CG = 1.5                # segundos entre caregivers


def _get_onedrive_root():
    """Detecta la ruta de OneDrive según el usuario del PC (reusa lógica de BGC)."""
    user     = getpass.getuser().lower()
    onedrive = f"C:\\Users\\{getpass.getuser()}\\OneDrive - Right At Home"
    RUTAS = {
        "a.pabuence": os.path.join(onedrive, "BGC_Anual"),
        "angel":      os.path.join(onedrive, "BGC_Anual"),
        "danny":      os.path.join(onedrive, "Angel Pabuence's files - BGC_Anual"),
        "d.tobon":    os.path.join(onedrive, "Angel Pabuence's files - BGC_Anual"),
    }
    if user in RUTAS:
        return RUTAS[user]
    shared = os.path.join(onedrive, "Angel Pabuence's files - BGC_Anual")
    own    = os.path.join(onedrive, "BGC_Anual")
    return shared if os.path.exists(shared) else own

# Reusa el mismo login_state.json que ya mantienes para BGC
LOGIN_STATE = os.path.join(_get_onedrive_root(), "login_state.json")

# ─────────────────────────────────────────────────────────────
#  HELPERS (compartidos con el generador)
# ─────────────────────────────────────────────────────────────

def log(msg, tipo="INFO"):
    simbolo = {"INFO": "->", "OK": "OK", "ERROR": "X", "WARN": "!"}.get(tipo, "->")
    print(f"  {simbolo} {msg}")

def clean(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", str(value))

def is_all_caps(value: str) -> bool:
    letters = [c for c in str(value) if c.isalpha()]
    return bool(letters) and all(c.isupper() for c in letters)

def is_excluded(first: str, last: str):
    if is_all_caps(first) and is_all_caps(last):
        return "ALL_CAPS_staff"
    f, l = first.strip().lower(), last.strip().lower()
    for ef, el in EXTRA_EXCLUDE:
        if f == ef.strip().lower() and (el is None or l == el.strip().lower()):
            return "EXTRA_EXCLUDE"
    return None

def find_roster(input_dir: str) -> Path:
    folder = Path(input_dir)
    files = [p for p in folder.iterdir()
             if p.suffix.lower() in (".xls", ".xlsx") and not p.name.startswith("~$")]
    if not files:
        raise FileNotFoundError(f"No .xls/.xlsx en {folder.resolve()}")
    return max(files, key=lambda p: p.stat().st_mtime)

def resolve_columns(df: pd.DataFrame) -> dict:
    norm = {re.sub(r"[^a-z0-9]", "", str(c).lower()): c for c in df.columns}
    def pick(*cands, contains=None):
        for k in cands:
            if k in norm: return norm[k]
        if contains:
            for k, original in norm.items():
                if contains in k: return original
        return None
    cols = {"first": pick("firstname", "fname", contains="first"),
            "last":  pick("lastname", "lname", contains="last")}
    missing = [k for k, v in cols.items() if v is None]
    if missing:
        raise KeyError(f"No encuentro columna(s) {missing}. Columnas: {list(df.columns)}")
    return cols

def gather_files(base: str):
    """Junta los PDFs de un CG desde las carpetas activas (por toggle)."""
    out = Path(OUTPUT_DIR)
    folders = []
    if UPLOAD_INITIAL: folders.append(out / "Initial_Training")
    if UPLOAD_YEAR:    folders.append(out / "Inservice_Year")
    files = []
    for folder in folders:
        if folder.exists():
            files.extend(sorted(folder.glob(f"{base}_*.pdf")))
    return files

# ─────────────────────────────────────────────────────────────
#  NAVEGACIÓN WELLSKY  (reusado verbatim de bgc_04)
# ─────────────────────────────────────────────────────────────

def buscar_caregiver(page, nombre_busqueda):
    from playwright.sync_api import TimeoutError as PWTimeout
    try:
        page.click("a.butPpl", timeout=8000)
        page.wait_for_selector("#profile_search", timeout=8000)
        page.fill("#profile_search", "")
        page.type("#profile_search", nombre_busqueda, delay=80)
        page.wait_for_selector(".ui-autocomplete a.item", timeout=8000)
        page.wait_for_timeout(500)
        resultados = page.query_selector_all(".ui-autocomplete a.item")
        if not resultados:
            return False
        resultados[0].click()
        page.wait_for_load_state("networkidle")
        return True
    except PWTimeout:
        return False
    except Exception as e:
        log(f"Error en búsqueda: {e}", "ERROR")
        return False

def obtener_edit_profile_id(page):
    try:
        link = page.query_selector('a.edit-profile[href*="/profile/edit/"][role="caregiver"]')
        if not link:
            link = page.query_selector('a.edit-profile[href*="/profile/edit/"]')
        if not link:
            return None
        match = re.search(r'/profile/edit/(\d+)/', link.get_attribute("href"))
        return match.group(1) if match else None
    except Exception as e:
        log(f"Error obteniendo edit_profile_id: {e}", "ERROR")
        return None

def subir_pdf(page, edit_profile_id, pdf_path, nombre_archivo):
    try:
        upload_url = f"{WELLSKY_URL.rstrip('/')}/profile/upload-file/{edit_profile_id}/"
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()
        response = page.request.post(
            upload_url,
            multipart={"userfile": {"name": nombre_archivo,
                                    "mimeType": "application/pdf",
                                    "buffer": pdf_bytes}},
            headers={"origin": WELLSKY_URL.rstrip("/"), "referer": page.url},
        )
        if response.status in [200, 201, 302]:
            return True
        log(f"Upload falló con status {response.status}", "ERROR")
        return False
    except Exception as e:
        log(f"Error subiendo {nombre_archivo}: {e}", "ERROR")
        return False

# ─────────────────────────────────────────────────────────────
#  ARMAR LA LISTA DE TAREAS DESDE EL EXCEL
# ─────────────────────────────────────────────────────────────

def build_tasks(cg_filter=None):
    roster = find_roster(INPUT_DIR)
    df = pd.read_excel(roster)
    df.columns = [str(c).strip() for c in df.columns]
    cols = resolve_columns(df)
    print(f"  Roster: {roster.name}  ({len(df)} filas)")

    tasks, excluidos = [], 0
    for _, r in df.iterrows():
        first = str(r[cols["first"]]).strip()
        last  = str(r[cols["last"]]).strip()
        if not first or first.lower() == "nan":
            continue
        if is_excluded(first, last):
            excluidos += 1
            continue
        base = f"{clean(last)}_{clean(first)}"
        if cg_filter and base.upper() != cg_filter.upper():
            continue
        files = gather_files(base)
        if not files:
            continue   # nada que subir para este CG bajo los toggles actuales
        tasks.append({"search": f"{first} {last}", "base": base, "files": files})
    return tasks, excluidos

# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

def main():
    global UPLOAD_INITIAL, UPLOAD_YEAR
    parser = argparse.ArgumentParser(description="Inservice WellSky Upload")
    parser.add_argument("--cg", default=None, help="Subir solo un CG, ej: Aiken_Sherrie")
    parser.add_argument("--dry-run", action="store_true",
                        help="Muestra qué subiría sin tocar WellSky")
    parser.add_argument("--initial", dest="initial", action="store_true", default=None)
    parser.add_argument("--no-initial", dest="initial", action="store_false")
    parser.add_argument("--year", dest="year", action="store_true", default=None)
    parser.add_argument("--no-year", dest="year", action="store_false")
    args = parser.parse_args()
    if args.initial is not None: UPLOAD_INITIAL = args.initial
    if args.year is not None:    UPLOAD_YEAR = args.year

    modo = " + ".join([s for s, on in [("Initial", UPLOAD_INITIAL), ("Year", UPLOAD_YEAR)] if on]) or "NADA"
    print(f"\n{'='*65}")
    print(f"  Inservice Upload WellSky — Right at Home Central Texas")
    print(f"  Subiendo: {modo}")
    print(f"{'='*65}\n")

    if not UPLOAD_INITIAL and not UPLOAD_YEAR:
        print("  Nada que subir: activa UPLOAD_INITIAL y/o UPLOAD_YEAR.")
        return

    tasks, excluidos = build_tasks(args.cg)
    total_pdfs = sum(len(t["files"]) for t in tasks)
    print(f"  CGs a procesar: {len(tasks)}  |  PDFs totales: {total_pdfs}  |  excluidos: {excluidos}\n")

    if not tasks:
        print("  No hay PDFs que coincidan. ¿Corriste inservice_generator.py con estos toggles?")
        return

    # ---- DRY RUN: solo muestra, no abre navegador ----
    if args.dry_run:
        print("  DRY-RUN (no se sube nada):\n")
        for t in tasks:
            print(f"  • {t['search']}  ({len(t['files'])} archivos)")
            for f in t["files"]:
                print(f"      - {f.name}")
        print(f"\n  Total: {len(tasks)} CGs, {total_pdfs} PDFs. Quita --dry-run para subir.")
        return

    # ---- UPLOAD REAL ----
    if not os.path.exists(LOGIN_STATE):
        print(f"  ERROR: no se encontró {LOGIN_STATE}")
        print(f"  Corre capture_login_state.py primero.")
        return

    print("  AVISO: el endpoint AGREGA archivos (no reemplaza). Corre una sola vez por lote.\n")

    from playwright.sync_api import sync_playwright

    total_subidos = total_fallidos = 0
    cgs_ok, cgs_fallidos, cgs_no_encontrado = [], [], []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        context = browser.new_context(storage_state=LOGIN_STATE)
        page    = context.new_page()

        page.goto(WELLSKY_URL, wait_until="networkidle")
        if "login" in page.url.lower():
            print("  ERROR: sesión expirada. Corre capture_login_state.py de nuevo.")
            browser.close()
            return
        log("Sesión WellSky activa", "OK")

        for i, t in enumerate(tasks, 1):
            print(f"\n  [{i}/{len(tasks)}] {t['search']}")
            if not buscar_caregiver(page, t["search"]):
                log(f"No encontrado en WellSky: {t['search']}", "ERROR")
                cgs_no_encontrado.append(t["search"])
                continue
            edit_id = obtener_edit_profile_id(page)
            if not edit_id:
                log("No se pudo obtener edit_profile_id", "ERROR")
                cgs_fallidos.append(t["search"])
                continue
            log(f"Perfil encontrado (ID: {edit_id})")

            subidos = fallidos = 0
            for f in t["files"]:
                if subir_pdf(page, edit_id, str(f), f.name):
                    log(f"{f.name}", "OK"); subidos += 1
                else:
                    log(f"{f.name}", "ERROR"); fallidos += 1
                time.sleep(0.3)

            total_subidos += subidos
            total_fallidos += fallidos
            (cgs_fallidos if fallidos else cgs_ok).append(t["search"])
            time.sleep(PAUSA_ENTRE_CG)

        browser.close()

    print(f"\n{'='*65}")
    print(f"  Upload completo.")
    print(f"  -> PDFs subidos:       {total_subidos}")
    print(f"  -> PDFs fallidos:      {total_fallidos}")
    print(f"  -> CGs completados:    {len(cgs_ok)}")
    print(f"  -> CGs con errores:    {len(cgs_fallidos)}")
    print(f"  -> CGs no encontrados: {len(cgs_no_encontrado)}")
    if cgs_no_encontrado:
        print("\n  No encontrados (subir a mano):")
        for c in cgs_no_encontrado: print(f"    - {c}")
    print(f"{'='*65}\n")


if __name__ == "__main__":
    main()
