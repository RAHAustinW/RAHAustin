@echo off
cd /d "%~dp0"
echo Generando INITIAL TRAINING para los que esten en input\ ...
python inservice_generator.py --initial --no-year
echo.
echo Revisa output_inservice\Initial_Training\  y luego usa SUBIR_nuevos_contratados.bat
pause
