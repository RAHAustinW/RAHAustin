# -*- coding: utf-8 -*-
"""Cierra el lote: archiva los PDFs subidos y el Excel procesado, deja todo limpio."""
import shutil
from datetime import datetime
from pathlib import Path

stamp = datetime.now().strftime("%Y%m%d_%H%M")
arch = Path("archivo"); arch.mkdir(exist_ok=True)

out = Path("output_inservice")
if out.exists() and any(out.iterdir()):
    dest = arch / f"{stamp}_output_inservice"
    shutil.move(str(out), str(dest))
    print(f"  PDFs movidos a:  {dest}")
else:
    print("  No hay output_inservice para archivar.")

inp = Path("input"); proc = inp / "procesados"; proc.mkdir(exist_ok=True)
moved = False
for f in list(inp.iterdir()):
    if f.is_file() and f.suffix.lower() in (".xls", ".xlsx") and not f.name.startswith("~$"):
        shutil.move(str(f), str(proc / f"{stamp}_{f.name}"))
        print(f"  Excel archivado: procesados/{stamp}_{f.name}")
        moved = True
if not moved:
    print("  No habia Excel en input para archivar.")
print("  Listo. input/ y output_inservice/ quedan limpios para el proximo lote.")
