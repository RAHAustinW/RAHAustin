INSERVICE RECORDS - PROCESO ESTANDARIZADO
Right at Home Central Texas

==================================================================
PASOS, SIEMPRE EN ESTE ORDEN
==================================================================
  1) Exporta el roster de WellSky (First Name / Last Name / Hire Date)
     y dejalo en la carpeta  input\
  2) GENERAR  (doble clic en el .bat segun lo que necesites)
  3) Revisa los PDFs en  output_inservice\
  4) SUBIR    (doble clic; primero muestra vista previa, pides confirmacion)
  5) ARCHIVAR (doble clic; guarda el lote y limpia para la proxima)

El Excel de input\ ES la lista: solo se procesa a quien este en ese archivo.

==================================================================
BOTONES SEGUN LO QUE NECESITES
==================================================================
NUEVOS CONTRATADOS (cada vez que entra gente)
   GENERAR_nuevos_contratados.bat   -> solo Initial Training
   SUBIR_nuevos_contratados.bat     -> sube solo Initial

INSERVICE ANUAL (una vez al ano)
   GENERAR_anual.bat                -> solo el record del ano actual
   SUBIR_anual.bat                  -> sube solo el anual

PRIMERA VEZ / PUESTA AL DIA (todo el historico)
   GENERAR_todo_historico.bat       -> Initial + todos los anos de antiguedad
   SUBIR_todo.bat                   -> sube ambos

CERRAR EL LOTE
   ARCHIVAR.bat  -> mueve output_inservice\ a archivo\<fecha> y el Excel a
                    input\procesados\<fecha>. Deja todo limpio.

(Avanzado: tambien puedes correr  python inservice_generator.py --initial --no-year
 etc. Los .bat solo son atajos a esas mismas opciones.)

==================================================================
QUE PASA CON LOS ARCHIVOS DESPUES DE SUBIR
==================================================================
Una vez SUBIR confirma OK, los PDFs ya estan en WellSky. Corre ARCHIVAR.bat:
guarda una copia con fecha en  archivo\  y limpia input\ y output_inservice\.
IMPORTANTE: el endpoint de WellSky AGREGA (no reemplaza). Si subes el mismo
lote dos veces, quedan duplicados. Por eso: subir una vez y archivar.

==================================================================
SETUP (una sola vez)
==================================================================
  pip install pandas PyMuPDF xlrd openpyxl playwright
  playwright install chromium
  login_state.json valido (el mismo de BGC; correr capture_login_state.py).

==================================================================
CAMBIO DE ANO (una vez, alrededor de julio)
==================================================================
  - Pon la plantilla nueva "July 20XX - June 20XX+1" en  templates\
    y actualiza TPL_YEAR en inservice_generator.py.
  - Sube CURRENT_YEAR al ano nuevo.
  De ahi en adelante usa GENERAR_anual / SUBIR_anual cada ano.
  Los anos del titulo y la fuente se detectan solos.

==================================================================
REGLAS FIJAS
==================================================================
  - Campo de nombre: "First Last/Caregiver"
  - Excluidos de AMBOS: filas en MAYUSCULA (staff) + Victoria (RN)
  - Initial: para todos, fecha = hire date
  - Anual: uno por ano de antiguedad (>=1 ano al 3-jul), fecha = 07/03/ese ano
