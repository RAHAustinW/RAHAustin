@echo off
cd /d "%~dp0"
echo Generando INSERVICE ANUAL (solo el ano actual) ...
python inservice_generator.py --no-initial --year --scope current
echo.
echo Revisa output_inservice\Inservice_Year\  y luego usa SUBIR_anual.bat
pause
