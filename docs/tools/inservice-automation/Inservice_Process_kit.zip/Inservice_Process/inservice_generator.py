#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Inservice Records — Standardized Annual Generator
Right at Home Central Texas
Author: Angel Pabuence

Reads a caregiver roster (First Name / Last Name / Hire Date) and produces two
sets of inservice PDFs, ready for upload to WellSky:

  Initial_Training/   one PDF per caregiver           date stamped = Hire Date
  Inservice_Year/     one PDF per YEAR of tenure       date stamped = 07/03/<year>

RULES
  - Staff Name/Title field = "First Last/Caregiver"
  - Exclusions (apply to BOTH document sets):
        * Any row where BOTH names are ALL-CAPS  -> office staff
        * Anyone in EXTRA_EXCLUDE (e.g. Victoria, the RN)
  - Initial Training: generated for every non-excluded caregiver, any tenure.
  - Inservice Year (annual, anchored on July 3):
        A caregiver gets one annual record for each July-3 checkpoint at which
        they had completed >= 1 year of service, through CURRENT_YEAR.
        Record for checkpoint year Y -> title "July (Y-1) - June Y",
        date stamped 07/03/Y, filename ..._Inservice_(Y-1)-Y.pdf

ANNUAL REUSE
  To run next year: swap TPL_YEAR for the new year's template and set
  CURRENT_YEAR. The script auto-detects the template's printed years and their
  position, and reuses the template's own Aptos font to relabel prior years, so
  no coordinates ever need editing.
"""

import re
import csv
import argparse
from pathlib import Path

import pandas as pd
import fitz  # PyMuPDF

# --------------------------------------------------------------------------- #
# CONFIG — set once; then it just runs every time
# --------------------------------------------------------------------------- #
INPUT_DIR   = "input"        # drop the WellSky Excel export here (.xls or .xlsx)
TPL_INITIAL = "templates/Inservice_Record_-_Initial_training.pdf"
TPL_YEAR    = "templates/Inservice_Record_For_Year_July_2025_-_June_2026.pdf"
OUTPUT_DIR  = "output_inservice"

CURRENT_YEAR = 2026          # most recent July-3 checkpoint to generate
TITLE        = "Caregiver"   # appended after the name -> "First Last/Caregiver"
DATE_FORMAT  = "%m/%d/%Y"

# WHAT TO GENERATE -- flip these per run
GENERATE_INITIAL = True      # Initial Training  (run whenever new people are hired)
GENERATE_YEAR    = True      # Inservice Year    (run once a year)

# For the Inservice Year, HOW MANY years:
#   "all"     -> one record per year of tenure  (use for the first/catch-up run)
#   "current" -> only the CURRENT_YEAR record   (use every following year)
YEAR_SCOPE = "all"

# People to exclude in addition to the ALL-CAPS rule.
# Use (first, last); set last to None to exclude by first name only.
EXTRA_EXCLUDE = [
    ("Victoria", None),      # RN — set her last name here when known
]

# Header stamp coordinates (PyMuPDF: y from TOP; both templates 792 x 612).
NAME_XY   = (150, 96)
DATE_XY   = (548, 97)
FONT      = "helv"
FONT_SIZE = 11
# --------------------------------------------------------------------------- #


def clean(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", str(value))


def is_all_caps(value: str) -> bool:
    letters = [c for c in str(value) if c.isalpha()]
    return bool(letters) and all(c.isupper() for c in letters)


def is_excluded(first: str, last: str):
    if is_all_caps(first) and is_all_caps(last):
        return "ALL_CAPS_staff"
    f, l = first.strip().lower(), last.strip().lower()
    for ef, el in EXTRA_EXCLUDE:
        if f == ef.strip().lower() and (el is None or l == el.strip().lower()):
            return "EXTRA_EXCLUDE"
    return None


def record_years(hire):
    """Checkpoint years Y (<= CURRENT_YEAR) where tenure >= 1 yr at 07/03/Y."""
    if pd.isna(hire):
        return []
    return [Y for Y in range(hire.year, CURRENT_YEAR + 1)
            if hire <= pd.Timestamp(Y - 1, 7, 3)]


def detect_title_years(template_path: str) -> dict:
    """Find the two 4-digit years in the title band and the template's Aptos font.

    Returns dict with start/end years, white-out boxes, write x, baseline y,
    and the embedded Aptos font bytes (for pixel-identical relabeling)."""
    doc = fitz.open(template_path)
    page = doc[0]

    words = [w for w in page.get_text("words")
             if w[4].isdigit() and len(w[4]) == 4 and w[1] < 70]
    words.sort(key=lambda w: w[0])
    if len(words) < 2:
        raise RuntimeError("Could not detect two title years in TPL_YEAR")
    (sx0, sy0, sx1, sy1, syr) = words[0][:5]
    (ex0, ey0, ex1, ey1, eyr) = words[1][:5]

    # Embedded Aptos subset that contains all digits 0-9
    aptos = None
    for f in page.get_fonts(full=True):
        xref, name = f[0], f[3]
        if "Aptos" in name:
            buf = doc.extract_font(xref)[3]
            if buf and all(fitz.Font(fontbuffer=buf).has_glyph(ord(d)) for d in "0123456789"):
                aptos = buf
                break

    pad = 1.5
    return {
        "start_year": int(syr), "end_year": int(eyr),
        "start_box": fitz.Rect(sx0 - pad, sy0 - pad, sx1 + pad, sy1 + pad),
        "end_box":   fitz.Rect(ex0 - pad, ey0 - pad, ex1 + pad, ey1 + pad),
        "start_x": sx0, "end_x": ex0,
        "baseline": sy1,            # digits: bbox bottom == baseline
        "aptos": aptos,
    }


def find_roster(input_dir: str) -> Path:
    """Pick the Excel to process from the input folder (newest if several)."""
    folder = Path(input_dir)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {folder.resolve()}")
    files = [p for p in folder.iterdir()
             if p.suffix.lower() in (".xls", ".xlsx") and not p.name.startswith("~$")]
    if not files:
        raise FileNotFoundError(f"No .xls/.xlsx file in {folder.resolve()} — drop the WellSky export there.")
    return max(files, key=lambda p: p.stat().st_mtime)


def resolve_columns(df: pd.DataFrame) -> dict:
    """Map flexible header names to first / last / hire, ignoring extra columns."""
    norm = {re.sub(r"[^a-z0-9]", "", str(c).lower()): c for c in df.columns}

    def pick(*candidates, contains=None):
        for key in candidates:
            if key in norm:
                return norm[key]
        if contains:
            for k, original in norm.items():
                if contains in k:
                    return original
        return None

    cols = {
        "first": pick("firstname", "fname", "givenname", contains="first"),
        "last":  pick("lastname", "lname", "surname", contains="last"),
        "hire":  pick("hiredate", "dateofhire", contains="hire"),
    }
    missing = [k for k, v in cols.items() if v is None]
    if missing:
        raise KeyError(f"Could not find column(s) for {missing}. "
                       f"Columns in file: {list(df.columns)}")
    return cols


def _stamp_header(page, staff_name, date_str):
    page.insert_text(NAME_XY, staff_name, fontsize=FONT_SIZE, fontname=FONT, color=(0, 0, 0))
    if date_str:
        page.insert_text(DATE_XY, date_str, fontsize=FONT_SIZE, fontname=FONT, color=(0, 0, 0))


def make_initial(out_path, staff_name, hire_str):
    doc = fitz.open(TPL_INITIAL)
    _stamp_header(doc[0], staff_name, hire_str)
    doc.save(out_path); doc.close()


def make_year(out_path, staff_name, year, tpl):
    doc = fitz.open(TPL_YEAR)
    page = doc[0]

    # Relabel the title only when the record year differs from the template's
    if year != tpl["end_year"]:
        page.insert_font(fontname="aptos", fontbuffer=tpl["aptos"])
        for box, x, value in [(tpl["start_box"], tpl["start_x"], year - 1),
                              (tpl["end_box"],   tpl["end_x"],   year)]:
            page.draw_rect(box, color=(1, 1, 1), fill=(1, 1, 1))
            page.insert_text((x, tpl["baseline"]), str(value),
                             fontsize=12, fontname="aptos", color=(0, 0, 0))

    _stamp_header(page, staff_name, f"07/03/{year}")
    doc.save(out_path); doc.close()


def _write_csv(path, fields, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    global GENERATE_INITIAL, GENERATE_YEAR, YEAR_SCOPE
    parser = argparse.ArgumentParser(description="Inservice generator")
    parser.add_argument("--initial", dest="initial", action="store_true", default=None)
    parser.add_argument("--no-initial", dest="initial", action="store_false")
    parser.add_argument("--year", dest="year", action="store_true", default=None)
    parser.add_argument("--no-year", dest="year", action="store_false")
    parser.add_argument("--scope", choices=["all", "current"], default=None)
    args = parser.parse_args()
    if args.initial is not None: GENERATE_INITIAL = args.initial
    if args.year is not None:    GENERATE_YEAR = args.year
    if args.scope:               YEAR_SCOPE = args.scope

    if not GENERATE_INITIAL and not GENERATE_YEAR:
        raise SystemExit("Nothing to do: set GENERATE_INITIAL and/or GENERATE_YEAR to True.")
    if YEAR_SCOPE not in ("all", "current"):
        raise SystemExit('YEAR_SCOPE must be "all" or "current".')

    out = Path(OUTPUT_DIR)
    dir_initial = out / "Initial_Training"
    dir_year    = out / "Inservice_Year"
    if GENERATE_INITIAL:
        dir_initial.mkdir(parents=True, exist_ok=True)
    if GENERATE_YEAR:
        dir_year.mkdir(parents=True, exist_ok=True)

    tpl = detect_title_years(TPL_YEAR) if GENERATE_YEAR else None
    if tpl and tpl["aptos"] is None:
        print("WARNING: Aptos font not found in template; relabeled years would use a fallback.")

    roster = find_roster(INPUT_DIR)
    df = pd.read_excel(roster)
    df.columns = [str(c).strip() for c in df.columns]
    cols = resolve_columns(df)
    print(f"Reading roster          : {roster.name}  ({len(df)} rows)")

    n_initial = n_year = 0
    excluded_rows, no_year_rows = [], []

    for _, r in df.iterrows():
        first, last = str(r[cols["first"]]).strip(), str(r[cols["last"]]).strip()
        hd = r[cols["hire"]]
        hd = pd.to_datetime(hd, errors="coerce")
        if not first or first.lower() == "nan":
            continue   # skip blank rows

        reason = is_excluded(first, last)
        if reason:
            excluded_rows.append({"First Name": first, "Last Name": last, "Reason": reason})
            continue

        staff_name = f"{first} {last}/{TITLE}"
        hire_str   = hd.strftime(DATE_FORMAT) if pd.notna(hd) else ""
        base       = f"{clean(last)}_{clean(first)}"

        if GENERATE_INITIAL:
            make_initial(str(dir_initial / f"{base}_Initial_Training.pdf"), staff_name, hire_str)
            n_initial += 1

        if GENERATE_YEAR:
            years = record_years(hd)
            if YEAR_SCOPE == "current":
                years = [Y for Y in years if Y == CURRENT_YEAR]
            if not years:
                no_year_rows.append({"First Name": first, "Last Name": last,
                                     "Hire Date": hire_str, "Note": "not eligible this run"})
            for Y in years:
                make_year(str(dir_year / f"{base}_Inservice_{Y-1}-{Y}.pdf"), staff_name, Y, tpl)
                n_year += 1

    _write_csv(out / "_excluded.csv", ["First Name", "Last Name", "Reason"], excluded_rows)
    if GENERATE_YEAR:
        _write_csv(out / "_no_year_record.csv", ["First Name", "Last Name", "Hire Date", "Note"], no_year_rows)

    print(f"Mode                    : "
          f"{'Initial' if GENERATE_INITIAL else ''}"
          f"{' + ' if GENERATE_INITIAL and GENERATE_YEAR else ''}"
          f"{('Year [' + YEAR_SCOPE + ']') if GENERATE_YEAR else ''}")
    if GENERATE_YEAR:
        print(f"Template years detected : {tpl['start_year']}-{tpl['end_year']}")
    if GENERATE_INITIAL:
        print(f"Initial Training PDFs   : {n_initial}   -> {dir_initial}")
    if GENERATE_YEAR:
        print(f"Inservice Year PDFs     : {n_year}   -> {dir_year}")
    print(f"Excluded (staff/RN)     : {len(excluded_rows)}   -> _excluded.csv")
    if GENERATE_YEAR:
        print(f"Not eligible this run   : {len(no_year_rows)}   -> _no_year_record.csv")


if __name__ == "__main__":
    main()
